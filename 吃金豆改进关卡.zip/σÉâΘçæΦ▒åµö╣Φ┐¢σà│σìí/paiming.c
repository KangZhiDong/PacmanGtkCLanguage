//讲链表的数据加上排名
void paiming(struct xinxi*head)
{
  struct xinxi*p;
  int n=0;
  if(head!=NULL)
  {
    printf("\nshuchushujuruxia:\n");
    for(p=head;p!=NULL;p=p->next)
    {
        p->paiming+=n;
     printf("%d\n%s\n%s\n%s\n%d\n",p->paiming,p->id,p->score,p->time,p->shijian);
     n++;
    }
    printf("zhanghaoshu:%dyijingpaiminghaollllllllllllkkkkkk\n\n",n);
  }
  else
    printf("meiyouzhanghaoxinxi!\n\n");
}
