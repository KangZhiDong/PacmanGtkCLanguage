//输出链表信息方便调试
void shuchu(struct xinxi*head)
{
  struct xinxi*p;
  int n=0;
  if(head!=NULL)
  {
    printf("\nshuchushujuruxia:\n");
    for(p=head;p!=NULL;p=p->next)
    {
     printf("%d\n%s\n%s\n%s\n%d\n",p->paiming,p->id,p->score,p->time,p->shijian);
     n++;
    }
    printf("zhanghaoshu:%d\n\n",n);
  }
  else
    printf("meiyouzhanghaoxinxi!\n\n");
}
