static GtkWidget *zhanghao;
static GtkWidget *jilu_window;

//现将此次录入的游戏信息放入链表
struct xinxi *insert(struct xinxi *head)
{ char i;
  struct xinxi *p;
  struct xinxi *p1;
  struct xinxi *p2;
 int a;
 char b[20];
 char c[20];
a=1;
strcpy(b,"867");
strcpy(c,alltime);



  p2=head;
  p=(struct id *)malloc(sizeof(struct xinxi));

    p->paiming=a;
    strcpy(p->id,gtk_entry_get_text(GTK_ENTRY(zhanghao)));
    strcpy(p->score,b);
    strcpy(p->time,c);
    p->shijian=shijian;

  if(head==NULL)/*原链表是空表*/
  {
  head=p;
  p->next=NULL;
  }
  else
  {
  while((strcmp(p->time,p2->time)>0)&&(p2->next!=NULL))

  {
    p1=p2;
    p2=p2->next;
   }
  if(strcmp(p->time,p2->time)<=0)
  {
  if(p2==head)/*p2是表头节点，p插入首节点之前*/
  {
  head=p;
  p->next=p2;
  }
  else
  {
  p1->next=p;
  p->next=p2;
  }
 }
  else
  {
  p2->next=p;
  p->next=NULL;
  }
 }

printf("charulianbiaole");

return(head);
}



//将链表中的游戏信息保存到文件
struct xinxi *save(struct xinxi*head)
{
    struct xinxi*p;
    int n=0;
    FILE*fp;
    if((fp=fopen("data.txt","w"))==NULL)
    {
        printf("bunengdakaiwenjian!kkkkkkkkkkkkkkkkkkkkkkkk\n");

    }

if(head!=NULL)
  {  for(p=head;p!=NULL;p=p->next)
    {
      fwrite(p,sizeof(struct xinxi),1,fp);
      n++;
    }
      printf("cicibaocunle%d\n\n",n);


  }
  else
    printf("meiyoushujubaocun!\n\n");
    fclose(fp);


    return head;
};


//调用保存游戏数据开始函数
void   on_save   (GtkButton *button,gpointer data)
{
 printf("000000000000000000");
head=loadnew();
shuchu(head);
head=insert(head);
printf("1111111111111111111你好");
head=sortbytime(head);
head=save(head);
shuchu(head);
on_saveok();
printf("%d    22222222222222222222",shijian);
}
