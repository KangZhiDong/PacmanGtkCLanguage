void on_choose1()
{
  strcpy(ditu,"sence1.txt");
  on_game();
}
void on_choose2()
{
 strcpy(ditu,"sence2.txt");
  on_game();
}
void on_choose3()
{
  strcpy(ditu,"sence3.txt");
  on_game();
}
void on_choose4()
{
 strcpy(ditu,"sence4.txt");
  on_game();
}
