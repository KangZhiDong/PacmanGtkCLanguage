static GtkWidget*xuanze_window;

GtkWidget*create_xuanze_window()
 {
 		GtkWidget *button;
		GtkWidget *table;
		GtkWidget *frame;
        GtkWidget *box;
		window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
		gtk_window_set_title(GTK_WINDOW(window),"勇士来选择关卡");
		gtk_window_set_default_size(GTK_WINDOW(window),500,400);
		gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
		gtk_container_set_border_width(GTK_CONTAINER(window),20);

        box=gtk_vbox_new(FALSE,0);
        gtk_container_add(GTK_CONTAINER(window),box);

		frame = gtk_frame_new("请选择以下关卡");
        gtk_container_add(GTK_CONTAINER(box),frame);


		table= gtk_table_new(4,4,FALSE);
		gtk_container_set_border_width(GTK_CONTAINER(table),10);
		gtk_table_set_row_spacings(GTK_TABLE(table),5);
		gtk_table_set_col_spacings(GTK_TABLE(table),5);
		gtk_container_add(GTK_CONTAINER(frame),table);
		button = gtk_button_new_with_label("关卡  1  ");
		gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,0,1);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_choose1),NULL);

		button = gtk_button_new_with_label("关卡  2  ");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,1,2);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_choose2),NULL);

		button = gtk_button_new_with_label("关卡  3  ");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,2,3);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_choose3),NULL);

		button = gtk_button_new_with_label("关卡  4  ");
		gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,3,4);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_choose4),NULL);
		gtk_widget_show_all(window);
		 gdk_window_set_cursor(gtk_widget_get_window(window),
        gdk_cursor_new_from_pixbuf(gdk_display_get_default(),
                gdk_pixbuf_new_from_file("mouse.png",NULL),
                0,0));
 return window;
 }
void on_xuanze(GtkButton*button,gpointer data)
{
    printf("xuanze");
xuanze_window=create_xuanze_window();
 gtk_widget_show(xuanze_window);
}
