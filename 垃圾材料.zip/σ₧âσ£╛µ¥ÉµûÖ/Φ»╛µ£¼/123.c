#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

#define LEFT 1
#define UP 2
#define RIGHT 3
#define DOWN 4

GdkPixbuf *create_pixbuf(const gchar* filename)
{
 GdkPixbuf *pixbuf;
 GError *error = NULL;
 pixbuf = gdk_pixbuf_new_from_file(filename, &error);
 if(!pixbuf) {
 fprintf(stderr, "%s\n", error->message);
 g_error_free(error);
 }
 return pixbuf;
}

/*定义点结构，保存蛇和豆子的点的相对位置*/
struct _point
{
int x;
int y;
};
typedef struct _point point;

static GdkPixbuf *pixbuf = NULL; /*背景图像*/
static GdkPixbuf *pix1 = NULL; /*蛇图像*/
static GdkPixbuf *pix2 = NULL; /*豆子图像*/
static GtkWidget *image[60][40]; /*高４０宽６０模拟蛇移动背景*/
static GtkWidget *label; /*显示小蛇长度的文字*/

gchar locate[30][2]; /*保存蛇的位置*/
gint slength; /*保存蛇的长度*/
gint now_forward = DOWN; /*蛇的当前运动方向*/
gint forward = DOWN; /*蛇的受控运动方向*/
gint level = 1; /*蛇的长度标记*/
static gint timer = 0; /*时钟标记*/
gint headx; /*蛇头*/
gint heady;
gint tailx; /*蛇尾*/
gint taily;
gint beanx; /*豆的位置*/
gint beany;

/*函数的声明*/
void init(gint length); /*初始化蛇的位置*/
void erase(); /*抹去尾部*/
void draw(); /*画上蛇头*/
void move(); /*移动蛇*/
void clean(); /*清除蛇*/

void game_run(); /*运行游戏*/
point rand_point(); /*产生随机数*/
void bean(); /*画豆*/

void key_press(GtkWidget* widget, GdkEventKey* event, gpointer data);
void on_begin_clicked(GtkWidget* button, gpointer data); /*点击开始*/
void on_end_clicked(GtkWidget* button, gpointer data); /*结束游戏*/






int main(int argc, char *argv[])
{
GtkWidget* window;
GtkWidget* table;
GtkWidget* vbox;
GtkWidget* bbox;
GtkWidget* button;
GtkWidget* sep;
gint i, j;

gtk_init(&argc, &argv);

window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
g_signal_connect(G_OBJECT(window), "destroy",
G_CALLBACK(gtk_main_quit), NULL);
g_signal_connect(G_OBJECT(window), "key_press_event",
G_CALLBACK(key_press), NULL);
gtk_window_set_title(GTK_WINDOW(window), "小蛇吃豆");
gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
gtk_container_set_border_width(GTK_CONTAINER(window), 5);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("tubiao.png"));

vbox = gtk_vbox_new(FALSE, 0);
gtk_container_add(GTK_CONTAINER(window), vbox);
table = gtk_table_new(20, 30, FALSE);
gtk_box_pack_start(GTK_BOX(vbox), table, FALSE, FALSE, 5);

pixbuf = gdk_pixbuf_new_from_file("back.png", NULL);
pix1 = gdk_pixbuf_new_from_file("snake.png", NULL);
pix2 = gdk_pixbuf_new_from_file("bean.png", NULL);
/*循环创建６０＊４０个背景图像*/
for(i=0; i<30; i++)
for(j=0; j<20; j++)
{
image[i][j] = gtk_image_new_from_pixbuf(pixbuf);
gtk_table_attach(GTK_TABLE(table), image[i][j],
i, i+1,
j, j+1,
GTK_FILL | GTK_EXPAND,
GTK_FILL | GTK_EXPAND,
0, 0);
}

sep = gtk_hseparator_new();
gtk_box_pack_start(GTK_BOX(vbox), sep, FALSE, FALSE, 5);
bbox = gtk_hbutton_box_new();
gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 5);
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox), GTK_BUTTONBOX_END);

label = gtk_label_new("小蛇的长度： 5");
gtk_box_pack_start(GTK_BOX(bbox), label, TRUE, TRUE, 5);
button = gtk_button_new_with_label("开始");
gtk_box_pack_start(GTK_BOX(bbox), button, TRUE, TRUE, 5);
g_signal_connect(G_OBJECT(button), "clicked",
G_CALLBACK(on_begin_clicked), NULL);
button = gtk_button_new_with_label("停止");
gtk_box_pack_start(GTK_BOX(bbox), button, TRUE, TRUE, 5);
g_signal_connect(G_OBJECT(button), "clicked",
G_CALLBACK(on_end_clicked), NULL);

init(5); /*画蛇*/
bean(); /*画豆*/

gtk_widget_show_all(window);
gtk_main();

return 0;
}





/*函数的实现*/
point rand_point()
{
point p;
p.x = g_random_int_range(0, 30);
p.y = g_random_int_range(0, 20);

return p;
}

void bean()
{
point p;
p = rand_point();
if(p.x == 5)
p.x++;
gtk_image_set_from_pixbuf(GTK_IMAGE(image[p.x][p.y]), pix2);

beanx = p.x;
beany = p.y;
}

void init(gint length)
{
gint i;
gint x, y;

for(i=0; i<length; i++)
{
locate[i][0] = 5;
locate[i][1] = i;
gtk_image_set_from_pixbuf(GTK_IMAGE(image[5][i]), pix1);
}
slength = length;
}

void clean()
{
gint i, x, y;
for(i=0; i<slength; i++)
{
x = locate[i][0];
y = locate[i][1];
gtk_image_set_from_pixbuf(GTK_IMAGE(image[x][y]), pixbuf);
}
}

void erase()
{
gtk_image_set_from_pixbuf(GTK_IMAGE(image[tailx][taily]), pixbuf);
}

void draw()
{
gtk_image_set_from_pixbuf(GTK_IMAGE(image[headx][heady]), pix1);
}

void move()
{
gint i, len;
gchar buf[1024];
len = slength - 1;
tailx = locate[0][0];
taily = locate[0][1];
headx = locate[len][0];
heady = locate[len][1];

/*改变不同的方向*/
switch(forward)
{
case LEFT:
erase();
headx--;
if(headx == -1)
headx = 29;
for(i=0; i<len; i++)
{
locate[i][0] = locate[i+1][0];
locate[i][1] = locate[i+1][1];
}

locate[len][0] = headx;
locate[len][1] = heady;
draw();
break;
case UP:
erase();
heady--;
if(heady == -1) heady = 19 ;
for(i=0; i<len; i++)
{
locate[i][0] = locate[i+1][0];
locate[i][1] = locate[i+1][1];
}
locate[len][0] = headx;
locate[len][1] = heady;
draw();
break;
case RIGHT:
erase();
headx++;
if(headx == 30) headx = 0 ;
for(i=0; i<len; i++)
{
locate[i][0] = locate[i+1][0];
locate[i][1] = locate[i+1][1];
}
locate[len][0] = headx;
locate[len][1] = heady;
draw();
break;
case DOWN:
erase();
heady++;
if(heady == 20) heady = 0 ;
for(i=0; i<len; i++)
{
locate[i][0] = locate[i+1][0];
locate[i][1] = locate[i+1][1];
}
locate[len][0] = headx;
locate[len][1] = heady;
draw();
break;
}

/*判断是否吃到豆子*/
if((beanx == headx) && (beany == heady))
{
level++;
if(level == 7)
{
sprintf(buf, "小蛇的长度: %d,已达最长", level*5);
system("pause") ;
}
//clean();
sprintf(buf, "小蛇的长度: %d", level*5);
gtk_label_set_text(GTK_LABEL(label), buf);
//now_forward = forward = DOWN;
//init(level*5);
bean();
}
}

void game_run()
{
move();
}
void key_press(GtkWidget* widget, GdkEventKey* event, gpointer data)
{
switch(event->keyval)
{
case GDK_Up:
if(now_forward != DOWN)
forward = now_forward = UP;
break;
case GDK_Down :
if(now_forward != UP)
forward = now_forward = DOWN;
break;
case GDK_Left :
if(now_forward != RIGHT)
forward = now_forward = LEFT;
break;
case GDK_Right :
if(now_forward != LEFT)
forward = now_forward = RIGHT;
break;
}
}
void on_begin_clicked(GtkWidget* button, gpointer data) /*点击开始*/
{
timer = gtk_timeout_add(500, (GtkFunction)game_run, NULL);
}

void on_end_clicked(GtkWidget* button, gpointer data) /*结束游戏*/
{
gtk_timeout_remove(timer);
}
