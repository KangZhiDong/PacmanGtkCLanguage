#include <gtk/gtk.h>
void my_clock(GtkWidget *label)
{
    time_t t;
    t=time(NULL);
    gtk_label_set_text(GTK_LABEL(label),ctime(&t));
}
int main(int argc,char **argv)
{
    GtkWidget *win;
    GtkWidget *label;
    gint time_id;
    gtk_init(&argc,&argv);
    win=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(win),"Clock");
    gtk_window_set_position(GTK_WINDOW(win),GTK_WIN_POS_CENTER);
    label=gtk_label_new(NULL);
    g_signal_connect(G_OBJECT(win),"destroy",G_CALLBACK(gtk_main_quit),NULL);
    gtk_container_add(GTK_CONTAINER(win),label);
    time_id=g_timeout_add(1000,(GtkFunction)my_clock,label);
    gtk_widget_show_all(win);
    gtk_main();
    g_source_remove(time_id);
    return 0;
}



 box=gtk_hbox_new(FALSE,2);
		 label=gtk_label_new(NULL);
		 gtk_box_pack_start(GTK_BOX(box),label,FALSE,FALSE,3);
		label=gtk_label_new(NULL);
		gtk_box_pack_start(GTK_BOX(box),label,FALSE,FALSE,3);
		button=gtk_button_new();
       gtk_container_add(GTK_CONTAINER(button),box);
		gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,4,5);
        time_id=g_timeout_add(1000,(GtkFunction)my_clock,label);
