#include <graphics.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <process.h>
#include <string.h>
#define UP 0x4800
#define DOWN 0x5000
#define LEFT 0x4B00
#define RIGHT 0x4D00
#define ESC 0x011b
int a[10][10];
char st[50];
int k=1;
int ni;
struct move
{
int x;
int y;
int r;
int direction;
}s={100,100,19,};
struct zou
{
int qh;
int wh;
int eh;
}zh={100,380,10};
int qw,qe,gh,lh;
struct go
{
int q;
int w;
int e;
}z={380,380,10};
int guai();
int qa,qb,g,l;
int draws();
int drawx();
int drawz();
int drawy();
int clear();
int error();
int get();
int win();
int guai2();
int guaimove2();
int nandu();
int main()
{
int i=0,j=0;
int ki=0;
FILE *fp;
char ch;
int gdriver,gmode;
gdriver=VGA;
gmode=VGAHI;
initgraph(&gdriver,&gmode,"c:\\TC20\\BGI");
nandu();
setbkcolor(15);
setcolor(6);
 if((fp=fopen(st,"r+"))==NULL)
 {
 printf("can not open!");
 exit(0);
 }
 fseek(fp,9,SEEK_SET);
 ch=fgetc(fp);
 while(ch!=EOF)
 {
                 if(ch!='\n')
                 {if(ch=='0')
				 {setfillstyle(1,4);
				 circle(60+40*i,60+40*j,17);
                 a[i][j]=0;
				 floodfill(60+40*i,60+40*j,6);}
				 if(ch=='1')
				  {setfillstyle(1,14);
				  rectangle(40+40*i,40+40*j,80+40*i,80+40*j);
				  a[i][j]=1;
				  floodfill(60+40*i,60+40*j,6);
				  }
				 i++;
				 }
                 else
                 {j++;
                  i=0;}
 ch=fgetc(fp);
 }
drawx();
guai();
guai2();
fclose(fp);
for(;;)
{
if(zh.qh==s.x&&zh.wh==s.y)
{
get();
break;
}
if(ki==ESC)
{get();
break;
}
if(s.y==z.w&&s.x==z.q)
{get();
break;}
if(kbhit())
{ki=bioskey(0);
switch(ki)
{
case UP:s.direction=0;break;
case DOWN:s.direction=1;break;
case LEFT:s.direction=2;break;
case RIGHT:s.direction=3;break;}
clear();
switch(s.direction)
{
case 0:s.y-=40;break;
case 1:s.y+=40;break;
case 2:s.x-=40;break;
case 3:s.x+=40;break;
default :break;
}
switch(s.direction)
{
case 0:draws();break;
case 1:drawx();break;
case 2:drawz();break;
case 3:drawy();break;
default :break;
}
guaimove();
guaimove2();
error();
}}
getch();
return 0;
}
int clear()
{
setcolor(8);
setfillstyle(1,15);
rectangle(s.x-20,s.y-20,s.x+20,s.y+20);
floodfill(s.x,s.y,8);
}
int drawx()
{setcolor(8);
setfillstyle(1,15);
rectangle(s.x-20,s.y-20,s.x+20,s.y+20);
floodfill(s.x,s.y,8);
setcolor(3);
setfillstyle(1,GREEN);
pieslice(s.x,s.y,0,250,19);
pieslice(s.x,s.y,290,360,19);
setfillstyle(1,RED);
circle(s.x-10,s.y+5,3);
floodfill(s.x-10,s.y+5,CYAN);
}
int draws()
{setcolor(8);
setfillstyle(1,15);
rectangle(s.x-20,s.y-20,s.x+20,s.y+20);
floodfill(s.x,s.y,8);
setcolor(3);
setfillstyle(1,GREEN);
pieslice(s.x,s.y,110,360,19);
pieslice(s.x,s.y,0,70,19);
setfillstyle(1,RED);
circle(s.x-10,s.y-5,3);
floodfill(s.x-10,s.y-5,CYAN);
}
int drawz()
{setcolor(8);
setfillstyle(1,15);
rectangle(s.x-20,s.y-20,s.x+20,s.y+20);
floodfill(s.x,s.y,8);
setcolor(3);
setfillstyle(1,GREEN);
pieslice(s.x,s.y,0,160,19);
pieslice(s.x,s.y,200,360,19);
setfillstyle(1,RED);
circle(s.x-10,s.y-5,3);
floodfill(s.x-10,s.y-5,CYAN);
}
int drawy()
{setcolor(8);
setfillstyle(1,15);
rectangle(s.x-20,s.y-20,s.x+20,s.y+20);
floodfill(s.x,s.y,8);
setcolor(3);
setfillstyle(1,GREEN);
pieslice(s.x,s.y,20,340,19);
setfillstyle(1,RED);
circle(s.x+10,s.y-5,3);
floodfill(s.x+10,s.y-5,CYAN);
}
int error()
{
int i,j;
i=(((s.x-20)/40)-1);
j=(((s.y-20)/40)-1);
if(a[i][j]==0)
{k++;
if(k==ni)
win();
a[i][j]=2;}
if(a[i][j]==1)
get();
}
int guai()
{
setcolor(8);
setfillstyle(1,3);
circle(z.q,z.w,z.e);
floodfill(z.q,z.w,8);
setcolor(6);
if(a[qa][qb]==0)
{setcolor(6);
setfillstyle(1,4);
circle(60+40*qa,60+40*qb,17);
floodfill(60+40*qa,60+40*qb,6);}
else
{
setcolor(9);
setfillstyle(1,15);
rectangle(g-20,l-20,g+20,l+20);
floodfill(g,l,9);
}
}
int get()
{
cleardevice();
closegraph();
clrscr();
printf("YOU DIE!\n");
printf("YOUR SCORE IS:%d",k);
}
int win()
{
cleardevice();
closegraph();
clrscr();
printf("YOU WIN!\n");
printf("YOUR SCORE IS:%d!",ni);
}
int guaimove()
{
int u,v,f;
g=z.q;
l=z.w;
qa=(((z.q-20)/40)-1);
qb=(((z.w-20)/40)-1);
u=random(4);
switch(u)
{
case 0:z.w-=40;break;
case 1:z.w+=40;break;
case 2:z.q-=40;break;
case 3:z.q+=40;break;
default :break;
}
v=(((z.q-20)/40)-1);
f=(((z.w-20)/40)-1);
if(a[v][f]==1)
{
z.q=g;
z.w=l;
guaimove();
}
guai();
}
int guai2()
{
setcolor(8);
setfillstyle(1,3);
circle(zh.qh,zh.wh,zh.eh);
floodfill(zh.qh,zh.wh,8);
setcolor(6);
if(a[qw][qe]==0)
{setcolor(6);
setfillstyle(1,4);
circle(60+40*qw,60+40*qe,17);
floodfill(60+40*qw,60+40*qe,6);}
else
{
setcolor(9);
setfillstyle(1,15);
rectangle(gh-20,lh-20,gh+20,lh+20);
floodfill(gh,lh,9);
}
}
int guaimove2()
{
int uh,vh,fh;
gh=zh.qh;
lh=zh.wh;
qw=(((zh.qh-20)/40)-1);
qe=(((zh.wh-20)/40)-1);
uh=random(4);
switch(uh)
{
case 0:zh.wh-=40;break;
case 1:zh.wh+=40;break;
case 2:zh.qh-=40;break;
case 3:zh.qh+=40;break;
default :break;
}
vh=(((zh.qh-20)/40)-1);
fh=(((zh.wh-20)/40)-1);
if(a[vh][fh]==1)
{
zh.qh=gh;
zh.wh=lh;
guaimove2();
}
guai2();
}
int nandu()
{int sa;
printf("PLEASE SELECT(1~3):");
scanf("%d",&sa);
switch(sa)
{
case 1:strcpy(st,"c:\\TC20\\scene1.txt");break;
case 2:strcpy(st,"c:\\TC20\\scene2.txt");break;
case 3:strcpy(st,"c:\\TC20\\scene3.txt");break;
}
switch(sa)
{
case 1:ni=64;break;
case 2:ni=58;break;
case 3:ni=40;break;
}
}
