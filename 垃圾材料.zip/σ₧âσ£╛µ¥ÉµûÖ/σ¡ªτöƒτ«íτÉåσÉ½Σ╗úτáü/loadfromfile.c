
static GtkWidget*load_window;
static GtkWidget *entry_loadlujin;

void on_loadfail()
{
printf("duqushibai");

GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 读取失败!\n";
			type = GTK_MESSAGE_ERROR;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);

gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}




struct student*loadfromfile()
{
    char file[40];
    struct student*p;
    struct student*p1;
    struct student*p3;
    struct student*p4;
    int n=0,i=0,j=0;

    FILE*fp;
    printf("shuruduqushujudelujin:");
    const gchar*loadlujin=gtk_entry_get_text(GTK_ENTRY(entry_loadlujin));
    printf("%s",loadlujin);
    if((fp=fopen(loadlujin,"r"))==NULL)
    {
        printf("bunnengdakaiwenjian!\n");

    on_loadfail();
    exit(0);
    }

    else
     {

        head =(struct student *)malloc(sizeof(struct student));
        if(fread(head,sizeof(struct student),1,fp)!=1)
            printf("meiyoushujukeyiduru!\n\n");

        p=head;
        n++;
        while(!feof(fp))
        {
          p1= (struct student *)malloc(sizeof(struct student));
          fread(p1,sizeof(struct student),1,fp);
          p->next=p1;
          p=p1;
          n++;
        }
        p->next=NULL;
     }
    n--;
    for(p3=head,i=0;p3!=NULL;p3=p3->next) i++;
     for(j=0,p4=head;j<i-2;j++)
     {
         p4=p4->next;
     }
     p4->next=NULL;



printf("ciciduquxueshengshu%d\n\n",n);

    fclose(fp);
    return head;
}

