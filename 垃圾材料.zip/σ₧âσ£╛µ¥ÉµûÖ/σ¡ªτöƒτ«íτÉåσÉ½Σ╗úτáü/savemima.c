struct id*savemima(struct id*head1)
{
    struct id*p;
    struct id*p1;
    int n=0;
    FILE*fp1;
    if((fp1=fopen("C:\\mima.txt","a"))==NULL)
    {
        printf("bunengdakaimimawenjian!kkkkkkkkkkkkkkkkkkkkkkkk\n");

    }

if(head1!=NULL)
  {  for(p=head1;p!=NULL;p=p->next)
    {
      fwrite(p,sizeof(struct id),1,fp1);
      n++;
    }
      printf("cicibaocunlemima%d\n\n",n);
shuchumima(head1);
printf("lurulemimawenjjianoooooooooooo");

  }
  else
    printf("meiyoumimabaocun!\n\n");
    fclose(fp1);

    return head1;
};
