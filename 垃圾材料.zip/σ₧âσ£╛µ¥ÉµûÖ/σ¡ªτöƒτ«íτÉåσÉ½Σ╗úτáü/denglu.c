/*创建splash窗口splash.c*/
#include<gtk/gtk.h>


void on_main_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(main_window);
}





GtkWidget* create_main_windowx()
{
	GtkWidget *window;
	GtkWidget *vbox;
	GtkWidget *bbox;
	GtkWidget *image;
	GtkWidget *button;

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
	g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(gtk_main_quit),NULL);
	gtk_window_set_title(GTK_WINDOW(window),"学生管理系统");
	gtk_container_set_border_width(GTK_CONTAINER(window),1);
	gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
	vbox = gtk_vbox_new(FALSE,0);
	gtk_container_add(GTK_CONTAINER(window),vbox);

	image = gtk_image_new_from_file("001.jpg");
	gtk_box_pack_start(GTK_BOX(vbox),image,TRUE,TRUE,0);

	bbox=gtk_hbox_new(FALSE,0);
	gtk_box_pack_start(GTK_BOX(vbox),bbox,TRUE,TRUE,0);

	button = gtk_button_new_with_label("                           点击进入                              ");
	 g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_mima),NULL);
	g_signal_connect(G_OBJECT(button),"released",G_CALLBACK(on_main_delete),NULL);

	gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,150);

    button = gtk_button_new_with_label("                           关于我们                              ");
	g_signal_connect(G_OBJECT(button),"released",G_CALLBACK(on_about),NULL);
	gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,5);


	gtk_widget_show_all(window);
	//gtk_main();
	return window;
}
