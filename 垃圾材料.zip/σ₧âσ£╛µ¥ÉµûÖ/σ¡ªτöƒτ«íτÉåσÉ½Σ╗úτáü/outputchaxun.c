void chaxunxinxi(struct student*p2)
{
  struct student*p;
  p=p2;
  int n=0;

    printf("\nyaoshanchuxueshengshuju:\n");

     printf("yaochaxunde\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s",p->num,p->name,p->sex,p->year,p->month,p->day,p->major,p->banji,p->adress,p->dorm,p->score0,p->score1,p->score2,p->xuefen);
     new_row1[0]=p->num;
     new_row1[1]=p->name;
     new_row1[2]=p->sex;
     new_row1[3]=p->year;
     new_row1[4]=p->month;
     new_row1[5]=p->day;
     new_row1[6]=p->major;
     new_row1[7]=p->banji;
     new_row1[8]=p->adress;
     new_row1[9]=p->dorm;
     new_row1[10]=p->score0;
     new_row1[11]=p->score1;
     new_row1[12]=p->score2;
     new_row1[13]=p->xuefen;
     n++;

     row_count1++;
    gtk_clist_append(GTK_CLIST(clist2),new_row1);

    printf("xueshengzongshu:%dkaishitu\n\n",n);

}
