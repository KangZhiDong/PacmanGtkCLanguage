
struct student*jianli(struct student*head)
{
    struct student*p1;
    struct student*p2;
    p2=head;

    printf("xianshuchumuqianxueshengshuju\n");
    shuchu(head);
        p1=(struct student*)malloc(sizeof(struct student));

        if(p1==NULL)
        {
            printf("鐢宠绌洪棿澶辫触!");
            exit(1);
        }

printf("1");
             strcpy(p1->num,new_row[0]);
           strcpy(p1->name,new_row[1]);
            strcpy(p1->sex,new_row[2]);
            strcpy(p1->year,new_row[3]);
            strcpy(p1->month,new_row[4]);
            strcpy(p1->day,new_row[5]);
            strcpy(p1->major,new_row[6]);
            strcpy(p1->banji,new_row[7]);
            strcpy(p1->adress,new_row[8]);
            strcpy(p1->dorm,new_row[9]);
            strcpy(p1->score0,new_row[10]);
            strcpy(p1->score1,new_row[11]);
            strcpy(p1->score2,new_row[12]);
            strcpy(p1->xuefen,new_row[13]);


printf("2");
        p1->next=NULL;
        if(head==NULL)
            head=p1;
        else
           {
            head=p1;
            p1->next=p2;
           }
printf("3");

     return head;
    }
