struct student*save(struct student*head)
{
    struct student*p;
    int n=0;
    FILE*fp;
    if((fp=fopen("C:\\data.txt","w"))==NULL)
    {
        printf("bunengdakaiwenjian!kkkkkkkkkkkkkkkkkkkkkkkk\n");

    }

if(head!=NULL)
  {  for(p=head;p!=NULL;p=p->next)
    {
      fwrite(p,sizeof(struct student),1,fp);
      n++;
    }
      printf("cicibaocunle%d\n\n",n);


  }
  else
    printf("meiyoushujubaocun!\n\n");
    fclose(fp);


    return head;
};
