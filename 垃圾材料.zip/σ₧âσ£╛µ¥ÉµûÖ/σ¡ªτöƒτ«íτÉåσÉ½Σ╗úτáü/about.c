/* 关于对话框 about.c */
#include <gtk/gtk.h>


void on_about_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(about_window);
}


static GtkWidget* credits_window;
GtkWidget* create_credits()
{
GtkWidget* window;
GtkWidget* vbox;
GtkWidget* notebook;
GtkWidget* page;
GtkWidget* label;

window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
gtk_widget_set_size_request (window, 300, 300);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
gtk_window_set_title(GTK_WINDOW(window),"联系维护人员");
vbox = gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
notebook = gtk_notebook_new();
gtk_box_pack_start(GTK_BOX(vbox),notebook,FALSE,FALSE,5);
page = gtk_vbox_new(FALSE,0);
label = gtk_label_new("   邮箱：     kzd666@163.com    \n\n\n \n\n \n\n\n                 worldkzd@gmail.com\n");
gtk_box_pack_start(GTK_BOX(page),label,FALSE,FALSE,5);
label = gtk_label_new("\n\n\n \n \n\n\n \n\n\n \n\n\n 客服qq：  337836629");
gtk_box_pack_start(GTK_BOX(page),label,FALSE,FALSE,5);
label = gtk_label_new("联系方式");
gtk_notebook_append_page(GTK_NOTEBOOK(notebook),page,label);
page = gtk_vbox_new(FALSE,0);
label = gtk_label_new(NULL);
gtk_label_set_markup(GTK_LABEL(label),"<span><big>\n\n\n\n\n第三小组有时间时再联系</big></span>");
gtk_box_pack_start(GTK_BOX(page),label,FALSE,FALSE,5);
label = gtk_label_new("联系时间");
gtk_notebook_append_page(GTK_NOTEBOOK(notebook),page,label);
gtk_widget_show_all(window);
return window;
}

void show_credits()
{
credits_window = create_credits();
gtk_widget_show(credits_window);
}

void on_about2_delete(GtkButton *button,gpointer data)
{
    gtk_widget_destroy(data);
}




GtkWidget*create_about_window()
{
GtkWidget* bbox;
GtkWidget* vbox;
GtkWidget* label;
GtkWidget* window;
GtkWidget* sep;
GtkWidget* image;
GtkWidget* button;

window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
gtk_widget_set_size_request (window, 300, 350);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(on_about_delete),NULL);
gtk_window_set_title(GTK_WINDOW(window),"关于我们");
gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_container_set_border_width(GTK_CONTAINER(window),10);
vbox = gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
image = gtk_image_new_from_file("123.jpg");
gtk_box_pack_start(GTK_BOX(vbox),image,FALSE,FALSE,5);
label = gtk_label_new(NULL);
gtk_label_set_markup(GTK_LABEL(label),"<span><big>学生管理系统beta1.0</big></span>");
gtk_box_pack_start(GTK_BOX(vbox),label,FALSE,FALSE,5);
label = gtk_label_new("design by 第三小组\n write by 第三组");
gtk_box_pack_start(GTK_BOX(vbox),label,FALSE,FALSE,5);
sep = gtk_hseparator_new();
gtk_box_pack_start(GTK_BOX(vbox),sep,FALSE,FALSE,5);
bbox = gtk_hbutton_box_new();
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_EDGE);
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
button = gtk_button_new_with_label("投诉开发人员");
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,25);
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(show_credits),NULL);
button = gtk_button_new_from_stock(GTK_STOCK_OK);
g_signal_connect(GTK_OBJECT(button),"clicked",G_CALLBACK(on_about2_delete),window);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,35);
gtk_widget_show_all(window);

return window;
}



void on_about(GtkButton*button,gpointer data)
{
 about_window=create_about_window();
 gtk_widget_show(about_window);
}
