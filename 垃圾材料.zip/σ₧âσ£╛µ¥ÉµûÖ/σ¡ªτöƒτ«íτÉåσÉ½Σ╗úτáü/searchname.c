static gchar *searchstuname;
static GtkWidget*search1_window;
static GtkWidget *entry_search1;
static GtkWidget*search1_window;

static gchar *searchstuname;


void searchname(head)
{
    struct student*p2;
    struct student*p1;
    char *name1;
    printf("shurumingzi：");


    searchstuname=gtk_entry_get_text(GTK_ENTRY(entry_search1));
 printf("%s",searchstuname);
name1=searchstuname;
    if(head==NULL)
  {
    printf("\nlianbiaoweikong!\n\n");
    return(head);
  }
    p2=head;
    while((strcmp(name1,p2->name)!=0)&& p2->next!=NULL)
  {
    p1=p2;
    p2=p2->next;
  }
    if((strcmp(name1,p2->name)==0))
      {
          printf("%s\n%s\n%c\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",p2->num,p2->name,p2->sex,p2->year,p2->month,p2->day,p2->major,p2->banji,p2->adress,p2->dorm,p2->score0,p2->score1,p2->score2,p2->xuefen);
            chaxunxinxi(p2);
      }
    else
        {printf("\meiyouzhegexuesheng!\n");
        on_searchfail();}
}
