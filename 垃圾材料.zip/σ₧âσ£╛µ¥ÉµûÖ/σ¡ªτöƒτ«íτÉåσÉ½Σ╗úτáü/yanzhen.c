#include"searchid.c"

void yanzhen()
{printf("kkkkkkkkkkaishiyanzhen\n");
//head1=loadmima();
searchid(head1);
}
