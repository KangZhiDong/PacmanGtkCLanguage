static GtkWidget*delname_window;
static GtkWidget *entry_delname;
static int delnamechenggong=1;

void on_delnamefail()
{
printf("baocunshujushibaichangkou");

GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 重名啦!图形化后续处理!\n";
			type = GTK_MESSAGE_ERROR;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}

struct student*delbyname(struct student*head)
{
  struct student*p2;
  struct student*p1;
  char num1[10];
  int i=0,j=1;
  printf("shuruyaoshanchuxuesheng：");
 const gchar*name1=gtk_entry_get_text(GTK_ENTRY(entry_delname));
  if(head==NULL)
  {
    printf("\nlianbiaoshikongde!\n\n");
    delnamechenggong=0;
    return(head);
  }
  p2=head;
    for(;p2!=NULL;p1=p2,p2=p2->next)
    if(strcmp(name1,p2->name)==0)
    {
     i++;}

if(i==0)
   {
      printf("meiyouzhegexuesheng!\n");
delnamechenggong=0;
printf("shanchushibaichangkou111111111");

GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 没有这个学生!\n";
			type = GTK_MESSAGE_ERROR;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);

      }

else if(i==1)
{
  ///////////////////////////////
   p2=head;
    while((strcmp(name1,p2->name)!=0)&& p2->next!=NULL)
  {
    p1=p2;
    p2=p2->next;
  }
  if((strcmp(name1,p2->name)==0))
  {
    if(p2==head)
     head=p2->next;
    else
     p1->next=p2->next;
     free(p2);
     printf("shanchule%skkkkkkkkkkk!\n\n",name1);
  }
  //////////////////////////////////

}

else
{
    /////////////////////////////////////
    printf("zhaodaol%dxuesheng\n",i);
    p2=head;
    for(;p2->next!=NULL;p1=p2,p2=p2->next)
     if(strcmp(name1,p2->name)==0)
    {
        printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",p2->num,p2->name,p2->sex,p2->year,p2->month,p2->day,p2->major,p2->banji,p2->adress,p2->dorm,p2->score0,p2->score2,p2->score2,p2->xuefen);
     }
  while(j)
  {

    printf("shuruyaoshanchudexuehao：");
    on_delnamefail();

    scanf("%s",num1);


  p2=head;
  while((strcmp(num1,p2->num)!=0)&& p2->next!=NULL)
  {
    p1=p2;
    p2=p2->next;
  }
  if((strcmp(num1,p2->num)==0))
  {
   if(strcmp(p2->name,name1)!=0)
    printf("\nshurudexuehaoyumingzibutong\n\n");
    else
    {if(p2==head)
     head=p2->next;
     else
     p1->next=p2->next;
     free(p2);
     printf("ooooooooooo%s学号为%skkkkkkkkkkkk!\n\n",name1,num1);
     j=0;
    }
   }
   else
    printf("\nshurudexuehao====budengyumingzi\n\n");
  }

   ///////////////////////////////////////
}

  return(head);
}
