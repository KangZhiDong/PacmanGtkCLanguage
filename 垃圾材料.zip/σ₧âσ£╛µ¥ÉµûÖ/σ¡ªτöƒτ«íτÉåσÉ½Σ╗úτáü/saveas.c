
static GtkWidget*saveas_window;
static GtkWidget *entry_savelujin;
static int baocunchenggong=1;

void on_savefail()
{
printf("baocunshujushibaichangkou");

GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 保存失败!\n";
			type = GTK_MESSAGE_ERROR;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}


struct student*saveas(struct student*head)
{   char *file;
    struct student*p;
    struct student*p1;
    int n=0;
    FILE*fp;
    printf("shuchubaocunlujin");
    const gchar*savelujin=gtk_entry_get_text(GTK_ENTRY(entry_savelujin));
       printf("%s",savelujin);
    if((fp=fopen(savelujin,"w"))==NULL)
    {
        printf("bunnengdakailujinwenjiankkkkkkkkkkkkkkkkkkkkkkkkkk!\n");
        on_savefail();
        baocunchenggong=0;
        on_saveas_delete();
        exit(0);
    }

if(head!=NULL)
  {  for(p=head;p!=NULL;p=p->next)
    {
      fwrite(p,sizeof(struct student),1,fp);
      n++;
    }
      printf("cicibaocunle%d\n\n",n);

  }
  else
    printf("meiyoushujubaocun!\n\n");
    fclose(fp);





    return head;
};
