void shuchu(struct student*head)
{
  struct student*p;
  int n=0;
  if(head!=NULL)
  {
    printf("\nshuchushujuruxia:\n");
    for(p=head;p!=NULL;p=p->next)
    {
     printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",p->num,p->name,p->sex,p->year,p->month,p->day,p->major,p->banji,p->adress,p->dorm,p->score0,p->score1,p->score2,p->xuefen);
     n++;
    }
    printf("xueshengzongshu:%d\n\n",n);
  }
  else
    printf("meiyouxueshengshuju!\n\n");
}
