void guangbi1(GtkButton *button,gpointer data)
{
    gtk_widget_destroy(xianshichaxun_win);
}
GtkWidget* create_button1 (gchar* stockid)
 {   //创建图像按钮
 GtkWidget *button;
 GtkWidget *image;
 image=gtk_image_new_from_stock(stockid,GTK_ICON_SIZE_MENU);
 button=gtk_button_new();
 gtk_container_add(GTK_CONTAINER(button),image);
 return button;
 }

GtkWidget* create_chaxun_window()
 {
 GtkWidget *window;
 GtkWidget *vbox;
 GtkWidget *bbox;
 GtkWidget *button;
 GtkTooltips *button_tips;
 window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
 g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(guangbi1),NULL);
 gtk_window_set_title(GTK_WINDOW(window),"学生管理系统------查询结果");
 gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
gtk_container_set_border_width(GTK_CONTAINER(window),10);
gtk_widget_set_size_request (window, 1250, 500);
vbox=gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
clist2=gtk_clist_new_with_titles(14,titles);
gtk_box_pack_start(GTK_BOX(vbox),clist2,TRUE,TRUE,5);
bbox=gtk_hbutton_box_new();
button_tips=gtk_tooltips_new();
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
gtk_box_set_spacing(GTK_BOX(bbox),5);
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
gtk_button_box_set_child_size(GTK_BUTTON_BOX(bbox),20,20);

searchnum(head);
gtk_widget_show_all(window);
return window;
 }

 void chaxuntu ()
 {
 xianshichaxun_win=create_chaxun_window();
 gtk_widget_show(xianshichaxun_win);
 }
