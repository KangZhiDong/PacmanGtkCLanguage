void guangbi2(GtkButton *button,gpointer data)
{
    gtk_widget_destroy(xianshichaxun_win1);
}


GtkWidget* create_chaxun_window1()
 {
 GtkWidget *window;
 GtkWidget *vbox;
 GtkWidget *bbox;
 GtkWidget *button;
 GtkTooltips *button_tips;
 window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
 g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(guangbi2),NULL);
 gtk_window_set_title(GTK_WINDOW(window),"学生管理系统------查询结果");
 gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
gtk_container_set_border_width(GTK_CONTAINER(window),10);
gtk_widget_set_size_request (window, 1250, 500);
vbox=gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
clist2=gtk_clist_new_with_titles(14,titles);
gtk_box_pack_start(GTK_BOX(vbox),clist2,TRUE,TRUE,5);
bbox=gtk_hbutton_box_new();
button_tips=gtk_tooltips_new();
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
gtk_box_set_spacing(GTK_BOX(bbox),5);
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
gtk_button_box_set_child_size(GTK_BUTTON_BOX(bbox),20,20);

searchname(head);


gtk_widget_show_all(window);
return window;
 }

 void chaxuntu1 ()
 {
 xianshichaxun_win1=create_chaxun_window1();
 gtk_widget_show(xianshichaxun_win1);
 }
