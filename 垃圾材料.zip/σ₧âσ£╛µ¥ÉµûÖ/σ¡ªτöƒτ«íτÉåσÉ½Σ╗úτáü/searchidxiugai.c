static GtkWidget*change_window;
static GtkWidget*entrya;
static GtkWidget*entryb;




void searchidxiugai(head1)
{
   const struct id*p2;
     struct id*p1;
    char zhanghao1[20];
    printf("zhanghao：");

    strcpy(zhanghao1,head2);
     const gchar*mimaxiugai=gtk_entry_get_text(GTK_ENTRY(entrya));
    printf("dengludezhanghao%s\n",zhanghao1);

    if(head1==NULL)
  {
    printf("\nlianbiaoshikongde!\n\n");
    return(head1);
  }
    p2=head1;
    while((strcmp(zhanghao1,p2->zhanghao)!=0)&& p2->next!=NULL)
  {
    p1=p2;
    p2=p2->next;
  }
    if((strcmp(zhanghao1,p2->zhanghao)==0))
       {
           printf("%s\nmuqianmima%s\n",p2->zhanghao,p2->denglumima);
           strcpy(p2->denglumima,mimaxiugai);
           printf("%s\nmuqianmima%s\n",p2->zhanghao,p2->denglumima);
  }
    else
        {printf("failzhanghao!\n");

		on_failurezhanghao();

        }
        return head1;
}
