
void on_load_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(load_window);
}


void on_loadqueding()
{
printf("从文件载入失败");
head=loadfromfile();
shuchu(head);
GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 已经成功从目标读取文件了!\n";
			type = GTK_MESSAGE_INFO;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
// j= rand()%9;
  //  image1=gtk_image_new_from_file(a[j]);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}

GtkWidget*create_loadformfile_window()
{
GtkWidget* bbox;
GtkWidget* vbox;
GtkWidget* label;
GtkWidget* window;
GtkWidget* sep;
GtkWidget* button;
GtkWidget* table;
window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(on_load_delete),NULL);
gtk_window_set_title(GTK_WINDOW(window),"输入路径");
gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_container_set_border_width(GTK_CONTAINER(window),10);
vbox = gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
table = gtk_table_new(5,2,FALSE);
gtk_box_pack_start(GTK_BOX(vbox),table,FALSE,FALSE,5);
label = gtk_label_new("选取数据的绝对路径：");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,0,1);
entry_loadlujin = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_loadlujin,1,2,0,1);
sep = gtk_hseparator_new();
gtk_box_pack_start(GTK_BOX(vbox),sep,FALSE,FALSE,5);
bbox = gtk_hbutton_box_new();
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_EDGE);
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
button = gtk_button_new_from_stock(GTK_STOCK_OK);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,25);

g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_loadqueding),NULL);
g_signal_connect(G_OBJECT(button),"released",G_CALLBACK(on_load_delete),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,35);
gtk_widget_show_all(window);
return window;
}
void on_loadfile(GtkButton*button,gpointer data)
{
 load_window=create_loadformfile_window();
 gtk_widget_show(load_window);
}
