#include <stdlib.h>
#include <gtk/gtk.h>
#include<string.h>
#include<time.h>
#include"zhuce.c"

void on_sub_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(sub_window);
}
static GtkWidget*image1;

static gchar*root="管理员登陆";
static gchar*user="学生登陆";
static gchar*newer="新用户注册";
static int shengyu=2;

gchar Name[] = "root";
gchar Pass[] = "111111";
gchar Yan1[]="63d4p";
gchar Yan2[]="aaymf";
gchar Yan3[]="pnkrk";
gchar Yan4[]="dknwr";
gchar Yan5[]="3dpqu";
gchar Yan6[]="wyffr";
gchar Yan7[]="afcnr";
gchar Yan8[]="3hdvm";
gchar Yan9[]="vwwad";


 gboolean button_press_callback(GtkWidget *event_box,GdkEventButton *event,gpointer data)
{
   // printf("hello");
    if(event->button==1)
       system("firefox https://aq.qq.com/cn2/findpsw/pc/pc_find_pwd_input_account?pw_type=0&aquin=");
        return(TRUE);
}






GtkWidget* huantupian()
{
    printf("kaishihuantu");

    static int m;
    char b[9][10]={"a.png","b.png","c.png","d.png","e.png","f.png","g.png","h.png","i.png"};
    srand((int)time(0));

     m= rand()%9;
    image1=gtk_image_new_from_file(b[m]);
    return image1;
}

void on_huantu()
{
 printf("zhunbeihuantu");
 image1=huantupian();

}

void on_failureyanzhen()
{
GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 验证码错误\n";
			type = GTK_MESSAGE_WARNING;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);

gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
tongji++;
if(tongji>=3)
{
   gtk_widget_destroy(sub_window);
   exit(0);
}
}
void on_failuremima()
{
GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 密码错误\n";
			type = GTK_MESSAGE_WARNING;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);

gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
tongji++;
if(tongji>=3)
{
   gtk_widget_destroy(sub_window);
   exit(0);
}
}
void on_failurezhanghao()
{
GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 帐号错误\n";
			type = GTK_MESSAGE_WARNING;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);

gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
tongji++;
if(tongji>=3)
{
   gtk_widget_destroy(sub_window);
   exit(0);
}
}

#include"yanzhen.c"
#include"xinxi1.c"

void yanzhenma()
{
   gtk_widget_destroy(sub_window);
   on_mima();
}

void on_button_clicked(GtkWidget*button,gpointer data)
{
    const gchar*username=gtk_entry_get_text(GTK_ENTRY(entry1));
    const gchar*password=gtk_entry_get_text(GTK_ENTRY(entry2));
    const gchar*yanzheng=gtk_entry_get_text(GTK_ENTRY(entry3));
   printf("用户名是: %s  ",username);
    g_print("密码是: %s  ",password);
    g_print("验证码: %s  ",yanzheng);
    if(strcmp(username,password)==0)
        a=2;
    printf("%d",a);
}



void login(GtkWidget *widget, gpointer data)
{

	const gchar*username=gtk_entry_get_text(GTK_ENTRY(entry1));
    const gchar*password=gtk_entry_get_text(GTK_ENTRY(entry2));
    const gchar*yanzheng=gtk_entry_get_text(GTK_ENTRY(entry3));
	printf("%s\n", username);
	printf("%s\n", password);
if((strcmp(Yan1,yanzheng) == 0)||(strcmp(Yan2,yanzheng) == 0)||(strcmp(Yan3,yanzheng) == 0)||(strcmp(Yan4,yanzheng) == 0)||(strcmp(Yan5,yanzheng) == 0)||(strcmp(Yan6,yanzheng) == 0)||(strcmp(Yan7,yanzheng) == 0)||(strcmp(Yan8,yanzheng) == 0)||(strcmp(Yan9,yanzheng) == 0))
{
yanzhen();
}
else
{
  printf("failureyanzhengma\n");
		on_failureyanzhen();
}
}



GtkWidget* create_sub_window()
{
    GtkWidget*window;
    GtkWidget*image;

    GtkWidget*image2;
    GtkWidget*box;
    GtkWidget*box0;
    GtkWidget*box1;
    GtkWidget*box2;
    GtkWidget*box3;
    GtkWidget*box4;
    GtkWidget*label1;
    GtkWidget*label2;
    GtkWidget*label3;
    GtkWidget*label4;
    GtkWidget*label5;
    GtkWidget*label6;
    GtkWidget*radio1;
    GtkWidget*radio2;
    GtkWidget*radio3;
    GSList*group;
    GtkWidget*button;
    GtkWidget*button1;
    GtkWidget*button6;
    GtkWidget*sep;
    GtkWidget*eventbox;

    window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window),"学生管理系统");
    g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(on_sub_delete),NULL);
    gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
    gtk_container_set_border_width(GTK_CONTAINER(window),20);
    gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
    box=gtk_vbox_new(FALSE,0);
    gtk_container_add(GTK_CONTAINER(window),box);
    box0=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box0,FALSE,FALSE,5);
    box1=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box1,FALSE,FALSE,5);
    box2=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box2,FALSE,FALSE,5);
    box3=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box3,FALSE,FALSE,5);
    box4=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box4,FALSE,FALSE,5);
    sep=gtk_hseparator_new();
    gtk_box_pack_start(GTK_BOX(box),sep,FALSE,FALSE,5);

    radio1=gtk_radio_button_new_with_label(NULL,root);
    g_signal_connect(G_OBJECT(radio1),"released",G_CALLBACK(on_button_clicked),NULL);
    gtk_box_pack_start(GTK_BOX(box0),radio1,FALSE,FALSE,5);

    group=gtk_radio_button_get_group(GTK_RADIO_BUTTON(radio1));
    radio2=gtk_radio_button_new_with_label(group,user);
    g_signal_connect(G_OBJECT(radio2),"released",G_CALLBACK(on_button_clicked),NULL);
    gtk_box_pack_start(GTK_BOX(box0),radio2,FALSE,FALSE,5);

    group=gtk_radio_button_get_group(GTK_RADIO_BUTTON(radio2));
    radio3=gtk_radio_button_new_with_label(group,newer);
    g_signal_connect(G_OBJECT(radio3),"released",G_CALLBACK(on_zhuce),NULL);
    gtk_box_pack_start(GTK_BOX(box0),radio3,FALSE,FALSE,5);



    label1=gtk_label_new("  用户名:");
    entry1=gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(box1),label1,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(box1),entry1,FALSE,FALSE,5);

    label2=gtk_label_new("     密码:");
    entry2=gtk_entry_new();
    gtk_entry_set_visibility(GTK_ENTRY(entry2),FALSE);
    gtk_box_pack_start(GTK_BOX(box2),label2,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(box2),entry2,FALSE,FALSE,5);


    label3=gtk_label_new("  验证码:");


   on_huantu();
button6=gtk_button_new_with_label("看不清,换一张");
    g_signal_connect(G_OBJECT(button6),"clicked",G_CALLBACK(yanzhenma),NULL);
   // g_signal_connect(G_OBJECT(button6),"clicked",G_CALLBACK(on_huantu),NULL);

    entry3=gtk_entry_new();
   gtk_box_pack_start(GTK_BOX(box3),label3,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(box3),entry3,FALSE,FALSE,5);
       gtk_box_pack_start(GTK_BOX(box3),image1,FALSE,FALSE,5);
     gtk_box_pack_start(GTK_BOX(box3),button6,FALSE,FALSE,5);
    eventbox=gtk_event_box_new();
    g_signal_connect(G_OBJECT(eventbox),"button_press_event",G_CALLBACK(button_press_callback),image);
    image=gtk_image_new_from_file("zhaohui.png");
    gtk_box_pack_start(GTK_BOX(box4),eventbox,FALSE,FALSE,150);
    gtk_container_add(GTK_CONTAINER(eventbox),image);



    button=gtk_button_new_with_label("登陆吧孩子");
    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(login),NULL);

    gtk_box_pack_start(GTK_BOX(box),button,FALSE,FALSE,0);

    gtk_widget_show_all(window);

   return window;
}

void on_mima(GtkButton*button,gpointer data)
{
  sub_window=create_sub_window();
  gtk_widget_show(sub_window);
}






