#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <glib/gthread.h>
#include "snake.h"
#include "wall.h"

#define  EVERY  DRAW_SIZE_WIDTH/LINE // each size of the grid

enum
{
	ELEM_TYPE_FOOD = -1,
	ELEM_TYPE_BODY = 1,
	ELEM_TYPE_HEAD = 2,
};


#define MAX_ARRAY_LEN LINE*LINE


static void 
_wall_snake_tail_delete(wall_t *wall);

static void 
_wall_food_show(wall_t *wall);

static void 
_wall_food_pos_set(wall_t *wall);
///////////////////////////////////
///////////////////////////////////
static void 
_wall_snake_tail_delete(wall_t *wall)
{
	g_print("=======>>in tail_delete()\n");
	
	snake_t *snake = wall->snake;
	int i = snake->cur;	
	switch (snake->tail_track[i])
	{
		case DOWN:
		 wall->grid[snake->tail_pos_x][snake->tail_pos_y++] = 0;
		 break;
		 
		case UP:
		 wall->grid[snake->tail_pos_x][snake->tail_pos_y--] = 0;
		 break;
		 
		case LEFT:
		 wall->grid[snake->tail_pos_x--][snake->tail_pos_y] = 0;
		 break;       
		 
		case RIGHT:
		 wall->grid[snake->tail_pos_x++][snake->tail_pos_y] = 0;
		 break;     
		 
		default:
		 break;
	}
	
	snake->cur++;
	if (snake->cur == SNAKE_MAX_LENGTH)
		snake->cur = 0;		
 
	g_print("=======>>out tail_delete()\n");
}

static void 
_wall_food_show(wall_t *wall)
{
	g_print("=======>>in food_show()\n");

	snake_t *snake = wall->snake;
	srand(snake->length);

	gint x = rand() % LINE;
	gint y = rand() % LINE;

	gint i = 0;
	gint j = 0;

	if (wall->grid[x][y] > 0) // avoid on the snake body
	{
		for(i=0;i<LINE;i++)
		{
			for(j=0;j<LINE;j++)
			{
			    if (wall->grid[i][j]==0 &&(wall->food_x != i && wall->food_x != j))
			    {
			       x = i ;
			       y = j;
			       break;
			    }
			}
		}
	}
	wall->grid[x][y] = -1; 
	g_print("=======>>out food_show()\n");
}

static void 
_wall_food_pos_set(wall_t *wall)
{
	wall->food_x = 6; // original food position
	wall->food_y = 6;

	wall->grid[wall->food_x][wall->food_y] = ELEM_TYPE_FOOD;  // food	
}

////////////////////////////////
wall_t*
wall_create()
{
	wall_t *wall = NULL;	
	wall = g_new(wall_t, 1);
	
	memset(wall, 0, sizeof(wall_t));	

	_wall_food_pos_set(wall);

	return wall;
}

void
wall_destroy(wall_t *wall)
{
	if (wall->snake)
		g_free(wall->snake);

	if (wall)
		g_free(wall);
}

void
wall_grid_clear(wall_t **wall)
{	
	memset((*wall)->grid, 0, sizeof((*wall)->grid));	
	_wall_food_pos_set(*wall);
}

void 
wall_snake_add(wall_t *wall, snake_t *snake)
{
	g_printf("=======>>in wall_snake_add()\n");
	
	int i = 0;
	wall->snake = snake;
	for (i = 0; i < snake->length-1; i++)
	{
	   wall->grid[0][i] = ELEM_TYPE_BODY; // body
	} 

	wall->grid[snake->head_pos_x][snake->head_pos_y] = ELEM_TYPE_HEAD; // head
	g_print("=======>>out wall_snake_add()\n"); 
}

void
wall_drawable_add(wall_t *wall, GtkWidget *draw)
{
	wall->draw = draw;
}

void 
wall_wall_draw(GtkWidget *draw)
{
	g_print("=======>>in draw_wall()\n");

	GdkGC *gc_white;   
	GdkColor color;

	gc_white = gdk_gc_new(draw->window);
	color.red = 65535;
	color.green = 65535;
	color.blue = 65535;
	gdk_gc_set_rgb_fg_color(gc_white, &color);
	
	gdk_draw_rectangle(draw->window, gc_white, FALSE, 0, 0, 
					DRAW_SIZE_WIDTH-1, DRAW_SIZE_HEIGHT-1);

	if (gc_white)	
		g_object_unref(G_OBJECT(gc_white));	
	
	g_print("=======>>out draw_wall()\n");
}

void 
wall_snake_food_draw(wall_t *wall)
{
	g_print("=======>>in snake_food_draw()\n");

	GdkGC *gc_blue;
	GdkGC *gc_red;
	GdkGC *gc_white;	
	
	gint i = 0;
	gint j = 0;

	GdkColor color;

	gc_blue = gdk_gc_new(wall->draw->window);
	color.red = 0;
	color.green = 0;
	color.blue = 65535;
	gdk_gc_set_rgb_fg_color(gc_blue,&color);

	gc_red = gdk_gc_new(wall->draw->window);
	color.red = 65535;
	color.green = 0;
	color.blue = 0;
	gdk_gc_set_rgb_fg_color(gc_red,&color);

   
	gc_white = gdk_gc_new(wall->draw->window);
	color.red = 65535;
	color.green = 65535;
	color.blue = 65535;
	gdk_gc_set_rgb_fg_color(gc_white, &color);

	for(i=0;i<LINE;i++)
	{
		for(j=0;j<LINE;j++)
		{
			if(wall->grid[i][j] == ELEM_TYPE_HEAD) // head
			{
				gdk_draw_rectangle(wall->draw->window,gc_white,TRUE,
								i*(EVERY)+3,j*(EVERY)+3,
								EVERY-4,EVERY-4);
			}
			
			/*if(wall->grid[i][j] == ELEM_TYPE_HEAD) //head
			{
				gdk_draw_pixbuf(GDK_DRAWABLE(wall->draw->window), NULL, GDK_PIXBUF(wall->snake->head), 
								0, 0,
								EVERY*i,j*EVERY,
								EVERY-4, EVERY-4,
								GDK_RGB_DITHER_MAX, 0, 0);    
			}*/
		
			if(wall->grid[i][j] == ELEM_TYPE_BODY) // body
			{
				gdk_draw_rectangle(wall->draw->window,gc_blue,TRUE,
								i*(EVERY)+3,j*(EVERY)+3,
								EVERY-5,EVERY-5);
			}

			if(wall->grid[i][j] == ELEM_TYPE_FOOD) // food
  			{
  				 gdk_draw_arc(wall->draw->window,gc_red,TRUE,
  				 				i*EVERY,j*EVERY,
  				 				EVERY,EVERY,0,64*360);			
  			}
		}
	}

	if (gc_white)
		g_object_unref(G_OBJECT(gc_white));

	if (gc_blue)	
		g_object_unref(G_OBJECT(gc_blue));
	
	if (gc_red)	
		g_object_unref(G_OBJECT(gc_red));	
	
	
	g_print("=======>>out snake_food_draw()\n");	
}

gboolean 
wall_snake_head_tail_update(wall_t *wall)
{
	g_print("=======>>in head_tail_update()\n");

	gboolean is_hit_wall = 0;
	snake_t *snake = wall->snake;

	wall->grid[snake->head_pos_x][snake->head_pos_y] = 1; // turn the head to body

	switch (snake->direction)
	{
		case DOWN:
		is_hit_wall = (snake->head_pos_y == LINE-1);	
		++snake->head_pos_y;		
		break;

		case UP:
		is_hit_wall = (snake->head_pos_y == 0);		
		--snake->head_pos_y;   
		break;

		case LEFT:
		is_hit_wall = (snake->head_pos_x == 0);
		--snake->head_pos_x;		
		break;  

		case RIGHT:
		is_hit_wall = (snake->head_pos_x == LINE-1);
		++snake->head_pos_x;  
		break;  

		default:
		break;
	}

	if (is_hit_wall) // hit the wall
	{
		g_print("hit the wall\n");
		return FALSE;
	} 
	else if (wall->grid[snake->head_pos_x][snake->head_pos_y] == ELEM_TYPE_FOOD)//eat food
	{ 
		g_print("=======>>eating food\n");	
		snake->length++;			
		_wall_food_show(wall);
	}
	else if (wall->grid[snake->head_pos_x][snake->head_pos_y] == ELEM_TYPE_BODY) //eat self
	{
		g_print("eating self\n");
		return FALSE;
	} 
	else 
	{
		_wall_snake_tail_delete(wall);
	}

	wall->grid[snake->head_pos_x][snake->head_pos_y] = ELEM_TYPE_HEAD; //set head of the snake

	snake->tail_track[snake->last++] = snake->direction;
	if (snake->last == SNAKE_MAX_LENGTH)
		snake->last = 0;		
	
	g_print("=======>>out head_tail_update() \n");	

	return TRUE;
}
