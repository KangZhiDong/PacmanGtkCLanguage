#ifndef _WALL_H_
#define _WALL_H_

#define _GTK_MAIN_WINDOW  0


#if _GTK_MAIN_WINDOW
#define DRAW_SIZE_WIDTH 480
#define DRAW_SIZE_HEIGHT 480
#define BUTTON_SIZE 100
#define DRAW_BUTTON_GAP 20
#else 
#define DRAW_SIZE_WIDTH 240
#define DRAW_SIZE_HEIGHT 240
#define BUTTON_SIZE 50
#define DRAW_BUTTON_GAP 10
#endif

#define  LINE  24   // the number of grid

typedef struct
{
	gint grid[LINE][LINE];
	
	gint food_x; // pos of food
	gint food_y;

	snake_t *snake;	
	GtkWidget *draw;
}wall_t;

/////////////////////////////
wall_t*
wall_create();

void
wall_destroy(wall_t *wall);

void 
wall_snake_add(wall_t *wall, snake_t *snake);

void
wall_drawable_add(wall_t *wall, GtkWidget *draw);

void 
wall_wall_draw(GtkWidget *draw);

void 
wall_snake_food_draw(wall_t *wall);

gboolean 
wall_snake_head_tail_update(wall_t *wall);

void
wall_grid_clear(wall_t **wall);


#endif
