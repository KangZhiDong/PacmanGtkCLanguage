#ifndef _SNAKE_H_
#define _SNAKE_H_

#define SNAKE_MAX_LENGTH 128

typedef enum
{
	UP = 1,
	DOWN,
	LEFT,
	RIGHT,  
} Direction;


typedef struct
{
	gint length;
	gint speed;
	Direction direction;

	gint head_pos_x;
	gint head_pos_y;

	gint tail_pos_x;
	gint tail_pos_y;	
	Direction tail_track[SNAKE_MAX_LENGTH];	

	gint cur;	// current pos of the tail_track
	gint last; // next available pos of the tail_track
	
	GdkPixbuf *head;	
}snake_t;

////////////////////////////////
snake_t*
snake_create();

void
snake_destroy(snake_t *snake);

void 
snake_clear(snake_t **snake);
#endif
