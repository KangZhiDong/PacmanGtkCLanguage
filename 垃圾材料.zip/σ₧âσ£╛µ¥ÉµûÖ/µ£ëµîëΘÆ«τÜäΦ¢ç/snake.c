#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <glib/gthread.h>
#include "snake.h"

#define SNAKE_ORIG_LENGTH 3


static void 
_snake_orignal_set(snake_t *snake);

/////////////////////////////////////////////
/////////////////////////////////////////////
static void 
_snake_orignal_set(snake_t *snake)
{
	int i = 0;
	
	snake->direction = DOWN;
	snake->length = SNAKE_ORIG_LENGTH;	
	snake->last = 0; // next available pos of the tail_track
	
	snake->head_pos_x = 0;
	snake->head_pos_y = snake->length-1;
			
	snake->cur = 0;
	
	snake->speed = 150;
	snake->tail_pos_x = 0;
	snake->tail_pos_y = 0;

	for (i = 0; i < snake->length-1; i++)
	{
		snake->tail_track[i] = snake->direction;		
		snake->last++;
	}
}

/////////////////////////////////

snake_t*
snake_create()
{
	snake_t *snake = NULL;
	int i = 0;
	snake = g_new(snake_t, 1);
	memset(snake, 0, sizeof(snake_t));

	_snake_orignal_set(snake);
	//snake->head = gdk_pixbuf_new_from_file_at_size("head.jpg", EVERY-4, EVERY-4, NULL);
	return snake;
}


void
snake_destroy(snake_t *snake)
{
	if (snake)
		g_free(snake);
}


void 
snake_clear(snake_t **snake)
{
	memset(*snake, 0, sizeof(snake_t));	
	_snake_orignal_set(*snake);
}



