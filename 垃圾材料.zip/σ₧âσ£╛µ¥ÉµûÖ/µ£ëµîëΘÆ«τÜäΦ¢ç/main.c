#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <glib/gthread.h>
#include <time.h>
#include "snake.h"
#include "wall.h"

#define OVER_STRING "Game Over!\nPress Start again."

#define UP_KEY     65362
#define DOWN_KEY   65364
#define LEFT_KEY   65361
#define RIGHT_KEY  65363
#define SPACE_KEY  32
#define ENTER_KEY  65293

GtkWidget *score_label;
GtkWidget *time_label;
GtkWidget *ratio_label;

static guint id = 0;
static time_t time_start = 0;
static time_t time_end = 0;
static time_t pause_time = 0;

/////////////////////////////////////////////
/////////////////////////////////////////////
static void 
destroy_cb(GtkWidget *widget,gpointer data)
{
	g_print("=======>>in destroy_cb()\n");
	wall_t *wall = (wall_t*)data;
	g_return_if_fail(wall != NULL);	
	
	snake_t *snake = wall->snake;

	if (snake)
	{
		snake_destroy(snake);
		snake = NULL;
	}

	if (wall)
	{
		wall_destroy(wall);
		wall = NULL;
	}
	g_print("=======>>out destroy_cb()\n");	
	gtk_main_quit();
}

////////////////////button press call back
static void 
up_button_press_cb(GtkButton *button, gpointer   user_data)
{
	g_print("up\n");

	wall_t *wall = (wall_t*)user_data;
	
	if (wall->snake->direction != DOWN)
		wall->snake->direction = UP;
}

static void 
down_button_press_cb(GtkButton *button, gpointer   user_data)
{
	g_print("Down\n");	 

	wall_t *wall = (wall_t*)user_data;	
	if (wall->snake->direction != UP)	  
		wall->snake->direction = DOWN;
}

static void 
left_button_press_cb(GtkButton *button, gpointer   user_data)
{
	g_print("Left\n");	

	wall_t *wall = (wall_t*)user_data;	
	if (wall->snake->direction != RIGHT)
		wall->snake->direction = LEFT;
}

static void 
right_button_press_cb(GtkButton *button, gpointer   user_data)
{
	g_print("Right\n");  

	wall_t *wall = (wall_t*)user_data;
	if (wall->snake->direction != LEFT)	   
	 	wall->snake->direction = RIGHT;
}
////////////////////////////////

static gboolean 
draw_expose_cb(GtkWidget *da,GdkEventExpose *event,gpointer data   )
{
	g_print("=======>>in draw_expose_cb()\n");
	
	wall_t *wall = (wall_t*)data;
	wall_snake_food_draw(wall);
	wall_wall_draw(wall->draw);
	
	g_print("=======>>out draw_expose_cb()\n");

	return TRUE;
}

static gboolean 
position_update(gpointer data) 
{
	g_print("=======>>in position_update()\n");

	gboolean ret = TRUE;
	char score[10];	
	char times[10];
	char ratio[10];
	int int_score = 0;
	int int_times = 0;
	double double_ratio = 0.0;
	
	GdkGC *gc_blue;
	GdkColor color;
	PangoLayout  *string_layout = NULL;	

	GDK_THREADS_ENTER();

	wall_t *wall = (wall_t*)data;
	snake_t *snake = wall->snake;

	gc_blue = gdk_gc_new(wall->draw->window);
	color.red = 0;
	color.green = 0;
	color.blue = 65535;
	gdk_gc_set_rgb_fg_color(gc_blue,&color);

	if (!wall_snake_head_tail_update(wall))
	{			
		string_layout = gtk_widget_create_pango_layout(wall->draw, OVER_STRING);
		gdk_draw_layout(wall->draw->window, gc_blue, DRAW_SIZE_WIDTH/2-BUTTON_SIZE, 
						DRAW_SIZE_HEIGHT/2-BUTTON_SIZE, string_layout);		
		ret = FALSE;		
	}
	else 
	{
		int_score =  snake->length-3;
		sprintf(score, "Scores: %d", int_score);
		gtk_label_set_label((GtkLabel*)score_label, score);

		time_end = time(NULL);
		int_times = time_end-time_start + pause_time;
		sprintf(times, "Seconds: %d",  int_times);
		gtk_label_set_label((GtkLabel*)time_label, times);

		double_ratio =((int_times == 0)? (0.0): (double)int_score*100/int_times);
		sprintf(ratio, "Ratio: %.2f",  double_ratio);
		gtk_label_set_label((GtkLabel*)ratio_label, ratio);
		
		gdk_window_invalidate_rect(wall->draw->window, NULL,  FALSE);
		g_print("=======>>after gdk_window_invalidate_rect \n");	
	}

#if 0
	if ((snake->length-2) % 3 == 0) // set the snake speed
	{
		g_timeout_add(snake->speed, position_update, wall);
		ret = FALSE;
	}
#endif
	 
	g_print("=======>>out position_update()\n");
	GDK_THREADS_LEAVE();
	return ret;

}

static void  
start_button_press_cb(GtkButton *button, gpointer user_data)  
{
	wall_t *wall = (wall_t*)user_data;
	snake_t *snake = wall->snake;	

    if (id != 0)
	{
		g_source_remove(id);
		snake_clear(&snake);
		wall_grid_clear(&wall);
		pause_time = 0;
	}
	time_start = time(NULL);
	id = g_timeout_add(snake->speed, (GSourceFunc)position_update, wall); 
}

static void 
key_press_cb(GtkWidget *widget,GdkEventKey *event, gpointer user_data)

{
	g_print("=======>>in key_press_cb()\n");
	g_print("press: %x\n",event->keyval);  //use debug

	wall_t *wall = (wall_t*)user_data;  

	snake_t *snake = wall->snake;	

	switch(event->keyval)
	{
		case LEFT_KEY: // left
			g_print("Left\n");  
			if (wall->snake->direction != RIGHT)
				wall->snake->direction = LEFT;
			break;

		case RIGHT_KEY: // right   
			g_print("Right\n");  
			if (wall->snake->direction != LEFT)     
				wall->snake->direction = RIGHT;
			break;

		case DOWN_KEY: //down
			g_print("Down\n");   
			if (wall->snake->direction != UP)      
			   wall->snake->direction = DOWN;
			break;

		case UP_KEY: //up
			g_print("up\n");
			if (wall->snake->direction != DOWN)
				wall->snake->direction = UP;
			break;

		case SPACE_KEY: //space
			g_print("Stop\n"); 

		    if (id != 0)
			{
				g_source_remove(id);
				id = 0;
				pause_time += (time_end - time_start);
			} 
			else 
			{
				time_start = time(NULL);
				id = g_timeout_add(snake->speed, (GSourceFunc)position_update, wall); 			
			}
			break;

		case ENTER_KEY: //enter
			g_print("Start and Restart\n"); 	

		    if (id != 0)
			{
				g_source_remove(id);
				snake_clear(&snake);
				wall_grid_clear(&wall);				
			}
			time_start = time(NULL);
			pause_time = 0;
			id = g_timeout_add(snake->speed, (GSourceFunc)position_update, wall); 			
			break;

		default:
			break;
	} 
}


int 
main(int argc, char *argv[])
{
	GtkWidget *fixed;
	GtkWidget *form;
	GtkWidget *window;
	GtkWidget *draw;

	GtkWidget *b_up; 
	GtkWidget *b_down; 
	GtkWidget *b_left; 
	GtkWidget *b_right; 

	GtkWidget *b_start;
	
	wall_t *wall;	
	snake_t *snake;
	
	if (!g_thread_supported()) 
	{
		g_thread_init(NULL);	
		gdk_threads_init();
	}

	GDK_THREADS_ENTER();

	
	gtk_init(&argc,&argv);

#if _GTK_MAIN_WINDOW
	window = gtk_main_window_new(GTK_WIN_STYLE_FULL);
#else 	
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
#endif
	gtk_window_set_title(GTK_WINDOW(window),"Snake"); 

	draw = gtk_drawing_area_new();
	gtk_widget_set_size_request(draw, DRAW_SIZE_WIDTH, DRAW_SIZE_HEIGHT);

	wall = wall_create();		
	snake = snake_create();

	wall_snake_add(wall, snake);
	wall_drawable_add(wall, draw);

	fixed = gtk_fixed_new();

	b_up = gtk_button_new_with_label("Up");
	gtk_widget_set_size_request(b_up, BUTTON_SIZE, BUTTON_SIZE);
	
	b_down = gtk_button_new_with_label("Down");
	gtk_widget_set_size_request(b_down, BUTTON_SIZE, BUTTON_SIZE);
	
	b_left = gtk_button_new_with_label("Left");
	gtk_widget_set_size_request(b_left, BUTTON_SIZE, BUTTON_SIZE);
	
	b_right = gtk_button_new_with_label("Right");
	gtk_widget_set_size_request(b_right, BUTTON_SIZE, BUTTON_SIZE);
	
	b_start = gtk_button_new_with_label("Start");
	gtk_widget_set_size_request(b_start, BUTTON_SIZE, BUTTON_SIZE);	

	score_label = gtk_label_new("Start!");
	time_label  = gtk_label_new("");
	ratio_label = gtk_label_new("");

	g_signal_connect(wall->draw,"expose_event",G_CALLBACK(draw_expose_cb),wall);
	
	g_signal_connect(b_up,"pressed",G_CALLBACK(up_button_press_cb),wall);	
	g_signal_connect(b_down,"pressed",G_CALLBACK(down_button_press_cb),wall);
	g_signal_connect(b_left,"pressed",G_CALLBACK(left_button_press_cb),wall);
	g_signal_connect(b_right,"pressed",G_CALLBACK(right_button_press_cb),wall);
	g_signal_connect(b_start, "pressed", G_CALLBACK(start_button_press_cb), wall);

	g_signal_connect(G_OBJECT(window),"delete-event", G_CALLBACK(gtk_main_quit),NULL); 
	g_signal_connect(G_OBJECT(window),"destroy",G_CALLBACK(destroy_cb),wall);	
	g_signal_connect(G_OBJECT(window),"key-press-event", G_CALLBACK(key_press_cb),wall); 

	gtk_fixed_put(GTK_FIXED(fixed), wall->draw, 0, 0);
	gtk_fixed_put(GTK_FIXED(fixed), b_up, (DRAW_SIZE_WIDTH-BUTTON_SIZE)/2, DRAW_SIZE_HEIGHT+DRAW_BUTTON_GAP);	
	gtk_fixed_put(GTK_FIXED(fixed), b_down, (DRAW_SIZE_WIDTH-BUTTON_SIZE)/2, DRAW_SIZE_HEIGHT+DRAW_BUTTON_GAP+ BUTTON_SIZE*2);
	gtk_fixed_put(GTK_FIXED(fixed), b_left, (DRAW_SIZE_WIDTH-BUTTON_SIZE*3)/2, DRAW_SIZE_HEIGHT+DRAW_BUTTON_GAP+ BUTTON_SIZE);
	gtk_fixed_put(GTK_FIXED(fixed), b_right, (DRAW_SIZE_WIDTH+BUTTON_SIZE)/2, DRAW_SIZE_HEIGHT+DRAW_BUTTON_GAP+ BUTTON_SIZE);
	
	gtk_fixed_put(GTK_FIXED(fixed), b_start, (DRAW_SIZE_WIDTH-BUTTON_SIZE)/2, DRAW_SIZE_HEIGHT+DRAW_BUTTON_GAP+ BUTTON_SIZE);

	gtk_fixed_put(GTK_FIXED(fixed), score_label, 0, DRAW_SIZE_HEIGHT+DRAW_BUTTON_GAP);
	gtk_fixed_put(GTK_FIXED(fixed), time_label, 0, DRAW_SIZE_HEIGHT+DRAW_BUTTON_GAP*2+BUTTON_SIZE*2);
	gtk_fixed_put(GTK_FIXED(fixed), ratio_label,  (DRAW_SIZE_WIDTH+BUTTON_SIZE)/2+DRAW_BUTTON_GAP,  DRAW_SIZE_HEIGHT+DRAW_BUTTON_GAP);
	
#if _GTK_MAIN_WINDOW
	gtk_main_window_title_hide(GTK_MAIN_WINDOW(window));
	form = gtk_form_new(FALSE);
	gtk_container_add(GTK_CONTAINER(form),fixed);

	gtk_main_window_add_form(GTK_MAIN_WINDOW(window), GTK_FORM(form));
	gtk_main_window_set_current_form(GTK_MAIN_WINDOW(window), GTK_FORM(form));
#else
	gtk_container_add(window, fixed);
#endif

	gtk_widget_show_all(window);

	gtk_main();
	GDK_THREADS_LEAVE();

	return 0;
}

