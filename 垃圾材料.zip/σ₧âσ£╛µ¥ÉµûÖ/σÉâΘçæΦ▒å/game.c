﻿#include<gtk/gtk.h>
#include<gdk/gdkkeysyms.h>

#include"lose.c"


struct play /*游戏中人物的结构体*/
{
	int x;
	int y;
};
struct play them[5],tail[5];
int a[30][40]={0};
/*2墙壁,1金豆,3自己,4敌人,0为白地*/


static GdkPixbuf *pixbuf = NULL; /*墙图像*/
static GdkPixbuf *pix0 = NULL; //dou
static GdkPixbuf *pix1 = NULL; /*熊图像*/
static GdkPixbuf *pix2 = NULL; /*怪物图像*/
static GdkPixbuf *pix3 = NULL;   //吃掉留下来的
static GtkWidget *image[40][30]; /*高４０宽６０模拟蛇移动背景*/
static GtkWidget *label; /*显示小蛇长度的文字*/
static GtkWidget *our_timer;
 int jifen=0;
int zongjifen;
enum _FORWARD { LEFT, UP, RIGHT, DOWN} ;
typedef enum _FORWARD Forward;
int xx[5][2];
static gchar* kzd_file[4] = {"w.png","d.png","s.png","a.png"};
static GtkWidget *kzd_image;
gchar locate[2];
gint forward = DOWN;
static gint timer = 0;
static gint timer1 = 0;
static gint timer_id = 0;
gint hour=0;
gint min=0;
gint sec=0;
gint kzdx; /*kzd的位置*/
gint kzdy;
int islose=0;
int kaishi=0;
int kaiqi=1;

//计算从文件读到数组后豆豆的个数
int jisuan(void)
{int q,p,k=0;
for(q=0;q<30;q++)
    for(p=0;p<40;p++)
    if(a[q][p]==1)
    k++;
return k;
}
//累计游戏时间
void timer_add()
{
    gchar buf[100];
    sec++;
    shijian++;
    if(sec==60)
    {
        min++;
        if(min==60)
        {
            hour++;
            min=0;
        }
    sec=0;
    }
    sprintf(buf,"  %d  :  %d  :  %d",hour,min,sec);
    gtk_label_set_text(GTK_LABEL(our_timer),buf);
    strcpy(alltime,buf);
}




//退出游戏
void quit_youxi()
{
    gtk_widget_destroy(game_window);
    gtk_timeout_remove(timer);
    gtk_timeout_remove(timer1);

}

//初始化怪物
void guaiwu()
{
them[0].x=2;them[0].y=15;
them[1].x=4;them[1].y=1;
them[2].x=8;them[2].y=16;
them[3].x=12;them[3].y=13;
them[4].x=13;them[4].y=7;
int i;
for(i=0;i<5;i++)
gtk_image_set_from_pixbuf(GTK_IMAGE(image[them[i].x][them[i].y]), pix2);


}
//怪物自动移动
void movethem(struct play *them)
{
	int m;
	for(m=0;m<5;m++)
	{tail[m].x = them[m].x;
     tail[m].y = them[m].y;
    }

	int i;
	srand(time(NULL));
	for(i=0;i<5;i++)
	{
		if(kzdx==them[i].x&&(them[i].y+1)==kzdy)
			{them[i].y++;islose=1;}
		else if(kzdx==them[i].x&&(them[i].y-1)==kzdy)
			{them[i].y--;islose=1;}
		else if(kzdy==them[i].y&&(them[i].x+1)==kzdx)
			{them[i].x++;islose=1;}
		else if(kzdy==them[i].y&&(them[i].x-1)==kzdx)
			{them[i].x--;islose=1;}
		else
		{
loop:
		xx[i][0]=rand()%4+1;
		if(xx[i][0]==1&&xx[i][1]==2||xx[i][0]==2&&xx[i][1]==1)
			goto loop;
		if(xx[i][0]==3&&xx[i][1]==4||xx[i][0]==4&&xx[i][1]==3)
			goto loop;
		xx[i][1]=xx[i][0];
		if(xx[i][0]==1)
		{them[i].x--;
		if(a[them[i].y][them[i].x]==2)
		{them[i].x++;goto loop;}
		}
		else if(xx[i][0]==2)
		{them[i].x++;
		if(a[them[i].y][them[i].x]==2)
		{them[i].x--;goto loop;}
		}
		else if(xx[i][0]==3)
		{them[i].y++;
		if(a[them[i].y][them[i].x]==2)
		{them[i].y--;goto loop;}
		}
		else if(xx[i][0]==4)
		{them[i].y--;
		if(a[them[i].y][them[i].x]==2)
		{them[i].y++;goto loop;}
		}
		}
	}
int g;
for(g=0;g<5;g++)
{gtk_image_set_from_pixbuf(GTK_IMAGE(image[them[g].x][them[g].y]), pix2);
if(a[tail[g].y][tail[g].x]==0)
    gtk_image_set_from_pixbuf(GTK_IMAGE(image[tail[g].x][tail[g].y]), pix3);
else if(a[tail[g].y][tail[g].x]==2)
    gtk_image_set_from_pixbuf(GTK_IMAGE(image[tail[g].x][tail[g].y]), pixbuf);
else if(a[tail[g].y][tail[g].x]==1)
    gtk_image_set_from_pixbuf(GTK_IMAGE(image[tail[g].x][tail[g].y]), pix0);
}

}
//怪物移动调用
void fun()/*移动中的判断*/
{

movethem(them);/*根据控制者的位置来决定敌人的移动方向*/

}

//初始化人物
void init()
{
gint i;
gint x, y;
locate[0] = 2;
locate[1] = 2;
gtk_image_set_from_pixbuf(GTK_IMAGE(image[2][2]), pix1);
}

//人走后填上背景色
void erase()
{
gtk_image_set_from_pixbuf(GTK_IMAGE(image[kzdx][kzdy]), pix3);
}
//画人的方向并且填上图片
void draw()
{
if(forward == UP)
pix1 = gdk_pixbuf_new_from_file("w.png", NULL);
else if(forward == LEFT)
pix1 = gdk_pixbuf_new_from_file("a.png", NULL);
else if(forward == RIGHT)
pix1 = gdk_pixbuf_new_from_file("d.png", NULL);
else if(forward == DOWN)
pix1 = gdk_pixbuf_new_from_file("s.png", NULL);
gtk_image_set_from_pixbuf(GTK_IMAGE(image[kzdx][kzdy]), pix1);
}

//移动人物
void move()
{
gint i;
gchar buf[1024];

kzdx = locate[0];
kzdy = locate[1];


/*改变不同的方向*/
switch(forward)
{
case LEFT:
erase();
kzdx--;
if(a[kzdy][kzdx]==2)
    kzdx++;
if(a[kzdy][kzdx]==1)
    {jifen++;
    a[kzdy][kzdx]=0;
    }
if(kzdx == -1)
kzdx = 39;
locate[0] = kzdx;
draw();
break;
case UP:
erase();
kzdy--;
if(a[kzdy][kzdx]==2)
    kzdy++;
if(a[kzdy][kzdx]==1)
    {jifen++;
    a[kzdy][kzdx]=0;
    }
if(kzdy == -1) kzdy = 29 ;
locate[1] = kzdy;
draw();
break;
case RIGHT:
erase();
kzdx++;
if(a[kzdy][kzdx]==2)
    kzdx--;
if(a[kzdy][kzdx]==1)
    {jifen++;
    a[kzdy][kzdx]=0;
    }
if(kzdx == 40) kzdx = 0 ;
locate[0] = kzdx;
draw();
break;
case DOWN:
erase();
kzdy++;
if(a[kzdy][kzdx]==2)
    kzdy--;
if(a[kzdy][kzdx]==1)
    {jifen++;
    a[kzdy][kzdx]=0;
    }
if(kzdy == 30) kzdy = 0 ;
locate[1] = kzdy;
draw();
break;
}


sprintf(buf, "当前积分: %d",jifen);
gtk_label_set_text(GTK_LABEL(label), buf);
//判断是否win
if(zongjifen==jifen)
{
sprintf(buf, "恭喜你完成了本关卡！");
gtk_label_set_text(GTK_LABEL(label), buf);
jifen=0;
on_end_clicked();
on_success();
}

//判断是否死亡

int k;
for(k=0;k<5;k++)
{if((kzdx == them[k].x) && (kzdy == them[k].y)||islose==1)
{

islose=0;
//jifen=0;
sprintf(buf, "你失败了");
gtk_label_set_text(GTK_LABEL(label), buf);
on_end_clicked();
on_lose();
}
}

}

//人物开始调用函数

void game_run()
{
move();

if(kaiqi==0)
gtk_timeout_remove(timer);
}


//检测键盘操作
 void key_press(GtkWidget* widget,GdkEventKey *event,gpointer data)
{
 if(kaishi==1)
 {switch (event->keyval)
 {
 case GDK_Up :
 forward = UP;
 move (forward);
 break;
 case GDK_Down :
 forward = DOWN;
 move (forward);
 break;
 case GDK_Left :
 forward = LEFT;
 move (forward);
 break;
 case GDK_Right :
 forward = RIGHT;
 move (forward);
 break;
 case GDK_k :
     {timer = gtk_timeout_add(200, (GtkFunction)game_run, NULL);
     kaiqi=1;
     }
 break;
 case GDK_g :
     kaiqi=0;
 }
 }
 }

//开始后的函数
 void on_begin_clicked(GtkWidget* button, gpointer data) /*点击开始*/
{

 if(kaiqi==1)
  timer = gtk_timeout_add(200, (GtkFunction)game_run, NULL);
timer1 = gtk_timeout_add(400, (GtkFunction)fun, NULL);
kaishi=1;
timer_id=gtk_timeout_add(1000,(GtkFunction)timer_add, NULL);
}

//暂停调用的函数
void on_end_clicked(GtkWidget* button, gpointer data) /*结束游戏*/
{

gtk_timeout_remove(timer);
gtk_timeout_remove(timer1);
kaishi=0;
gtk_timeout_remove(timer_id);
}

//运行游戏窗口
 GtkWidget*create_game_window()
 {
 GtkWidget *window;
 GtkWidget *vbox;
 GtkWidget *bbox;
 GtkWidget *sep;
 GtkWidget *button;
 GtkWidget* table;
 int i=0, j=0;
 char ch;
FILE *fp;
if((fp=fopen("sence.txt","r+"))==NULL)
 {
 printf("can not open!");
 exit(0);
 }
ch=fgetc(fp);
while(ch!=EOF)
{
    if(ch!='\n')
                 {if(ch=='2')

				 a[i][j]=2;
				 if(ch=='1')
				  {
				  a[i][j]=1;

				  }
				 j++;
				 }
                 else
                 {i++;
                  j=0;}
 ch=fgetc(fp);
}
fclose(fp);
zongjifen=jisuan();
printf("%d",zongjifen);
//zongjifen=20;
 window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
 gtk_window_set_title(GTK_WINDOW(window),"吃金豆游戏中      k:开始自动跑    g：关闭自动跑");
 gtk_container_set_border_width(GTK_CONTAINER(window),10);
 gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("game.png"));
 g_signal_connect(G_OBJECT(window),"destroy",G_CALLBACK(quit_youxi),NULL);
 g_signal_connect(G_OBJECT(window),"key_press_event",G_CALLBACK(key_press),NULL);

 vbox = gtk_vbox_new(FALSE,0);
 gtk_container_add(GTK_CONTAINER(window),vbox);

table = gtk_table_new(30, 40, FALSE);
gtk_box_pack_start(GTK_BOX(vbox), table, FALSE, FALSE, 5);
pixbuf = gdk_pixbuf_new_from_file("qiang.png", NULL);
pix0 = gdk_pixbuf_new_from_file("dou.png", NULL);
pix1 = gdk_pixbuf_new_from_file("s.png", NULL);
pix2 = gdk_pixbuf_new_from_file("guai.png", NULL);
pix3 = gdk_pixbuf_new_from_file("back.png", NULL);
/*2墙壁,1金豆,3自己,4敌人,0为白地*/
for(i=0; i<40; i++)
for(j=0; j<30; j++)
{
if(a[j][i]==0)
{image[i][j] = gtk_image_new_from_pixbuf(pix3);
gtk_table_attach(GTK_TABLE(table), image[i][j],
i, i+1,
j, j+1,
GTK_FILL | GTK_EXPAND,
GTK_FILL | GTK_EXPAND,
0, 0);}
if(a[j][i]==1)
{image[i][j] = gtk_image_new_from_pixbuf(pix0);
gtk_table_attach(GTK_TABLE(table), image[i][j],
i, i+1,
j, j+1,
GTK_FILL | GTK_EXPAND,
GTK_FILL | GTK_EXPAND,
0, 0);}
if(a[j][i]==2)
{image[i][j] = gtk_image_new_from_pixbuf(pixbuf);
gtk_table_attach(GTK_TABLE(table), image[i][j],
i, i+1,
j, j+1,
GTK_FILL | GTK_EXPAND,
GTK_FILL | GTK_EXPAND,
0, 0);}
}


 sep = gtk_hseparator_new();
 gtk_box_pack_start(GTK_BOX(vbox),sep,FALSE,FALSE,5);

 bbox = gtk_hbutton_box_new();
 gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
 gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);

label = gtk_label_new("时间");
gtk_box_pack_start(GTK_BOX(bbox), label, TRUE, TRUE, 5);

our_timer = gtk_label_new(NULL);
gtk_box_pack_start(GTK_BOX(bbox), our_timer, TRUE, TRUE, 5);

label = gtk_label_new("当前游戏积分： 0");
gtk_box_pack_start(GTK_BOX(bbox), label, TRUE, TRUE, 5);

button = gtk_button_new_with_label("开始");
gtk_box_pack_start(GTK_BOX(bbox), button, TRUE, TRUE, 5);
g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(on_begin_clicked), NULL);

button = gtk_button_new_with_label("暂停");
gtk_box_pack_start(GTK_BOX(bbox), button, TRUE, TRUE, 5);
g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(on_end_clicked), NULL);

button = gtk_button_new_with_label("退出返回菜单");
gtk_box_pack_start(GTK_BOX(bbox), button, TRUE, TRUE, 5);
//g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(on_end_clicked), NULL);
g_signal_connect(G_OBJECT(button), "clicked",G_CALLBACK(quit_youxi), NULL);

// button = gtk_button_new_from_stock(GTK_STOCK_QUIT);
// g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(quit_youxi),NULL);
gtk_box_pack_end(GTK_BOX(bbox),button,FALSE,FALSE,5);


  init();
  guaiwu();

 gtk_widget_show_all(window);

  gdk_window_set_cursor(gtk_widget_get_window(window),
        gdk_cursor_new_from_pixbuf(gdk_display_get_default(),
                gdk_pixbuf_new_from_file("game.png",NULL),
                0,0));  //mouse.png为要使用的光标
 //gtk_main();
 return window;
 }

//开始调用游戏函数
void on_game(GtkButton*button,gpointer data)
{
    printf("game");
    on_quitsuccess_delete();
 game_window=create_game_window();
 gtk_widget_show(game_window);
}
