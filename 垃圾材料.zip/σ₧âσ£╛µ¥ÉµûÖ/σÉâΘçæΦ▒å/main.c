#include<gtk/gtk.h>
#include<stdlib.h>
#include <gdk/gdk.h>
#include<string.h>
struct xinxi
{
   int paiming;
   char id[20];
   char score[20];
   char time[20];
   int shijian;
   struct xinxi*next;
};
struct xinxi*head=NULL;
static gchar* titles[4]={"     排名       ","       姓名        ",  "    积分   ","   时间  "};
static GtkWidget *clist;
const gchar *new_row[4];
gint current_row = 0;
gint row_count = 0;
char alltime[20];
GtkWidget* window;
int shijian=0;
//static GtkWidget*feiqi_window;
static GtkWidget*game_window;
//设置图标
GdkPixbuf *create_pixbuf(const gchar* filename)
{
 GdkPixbuf *pixbuf;
 GError *error = NULL;
 pixbuf = gdk_pixbuf_new_from_file(filename, &error);
 if(!pixbuf) {
 fprintf(stderr, "%s\n", error->message);
 g_error_free(error);
 }
 return pixbuf;
}
//调用时间日期
void my_clock(GtkWidget *label)
{
    time_t t;
    t=time(NULL);
    gtk_label_set_text(GTK_LABEL(label),ctime(&t));
}
#include"sort.c"
#include"load.c"
#include"output.c"
#include"quittu.c"
#include"about.c"
//#include"feiqi.c"
#include"game.c"
#include"paimingtu.c"
#include"success.c"

//主界面
    int main(int argc,char*argv[])
	{

		  gtk_init(&argc,&argv);
		GtkWidget *button;
		GtkWidget *table;
		GtkWidget *frame;
        GtkWidget *box;
		gint time_id;
		window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
		gtk_window_set_title(GTK_WINDOW(window),"欢迎来到    吃金豆    游戏");
		gtk_window_set_default_size(GTK_WINDOW(window),500,400);
		gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
		gtk_container_set_border_width(GTK_CONTAINER(window),20);

		g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(gtk_main_quit),NULL);

        box=gtk_vbox_new(FALSE,0);
        gtk_container_add(GTK_CONTAINER(window),box);

		frame = gtk_frame_new("欢迎来到 吃金豆 适龄范围：2岁以上18岁以下\n抵制不良游戏  拒绝盗版游戏  注意自我保护  谨防上当受骗  \n适度游戏益脑  沉迷游戏伤身  合理安排时间  享受健康生活\n游戏菜单如下:");
        gtk_container_add(GTK_CONTAINER(box),frame);


		table= gtk_table_new(4,4,FALSE);
		gtk_container_set_border_width(GTK_CONTAINER(table),10);
		gtk_table_set_row_spacings(GTK_TABLE(table),5);
		gtk_table_set_col_spacings(GTK_TABLE(table),5);
		gtk_container_add(GTK_CONTAINER(frame),table);
		button = gtk_button_new_with_label("开始游戏");
		gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,0,1);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_game),NULL);

		button = gtk_button_new_with_label("查看排名");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,1,2);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_paiming),NULL);

		button = gtk_button_new_with_label("查看说明");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,2,3);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_about),NULL);

		button = gtk_button_new_with_label("退出游戏");
		gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,3,4);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_quit),NULL);

        label=gtk_label_new(NULL);
        gtk_container_add(GTK_CONTAINER(box),label);
        time_id=g_timeout_add(1000,(GtkFunction)my_clock,label);

		gtk_widget_show_all(window);
		 gdk_window_set_cursor(gtk_widget_get_window(window),
        gdk_cursor_new_from_pixbuf(gdk_display_get_default(),
                gdk_pixbuf_new_from_file("mouse.png",NULL),
                0,0));  //mouse.png为要使用的光标
		gtk_main ();
		 g_source_remove(time_id);
		return 0;
	}
