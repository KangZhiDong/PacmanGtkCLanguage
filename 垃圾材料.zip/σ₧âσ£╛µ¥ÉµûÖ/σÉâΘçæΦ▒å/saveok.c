//游戏保存成功后提示窗口
void on_saveok()
{
printf("baocunle");
GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 已经成功保存游戏信息了!\n";
			type = GTK_MESSAGE_INFO;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}

