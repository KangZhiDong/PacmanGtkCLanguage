#include <gtk/gtk.h>

typedef struct
{
    int x;
    int y;
}DATA;

void get_position(GtkWidget *win,GdkEventButton *event,DATA *data)
{
    int x,y;

    gtk_widget_get_pointer(win,&x,&y);
    data->x=x;
    data->y=y;  //�õ���ǰ����λ��
}

void move(GtkWidget *win,GdkEventButton *event,DATA *data)
{
    gtk_window_move(GTK_WINDOW(win),event->x_root-data->x,
            event->y_root-data->y);  //�ƶ����ڣ�����������ƶ���ͼƬ�����
}

int main(int argc,char **argv)
{
    GtkWidget *win;
    GdkPixbuf *pixbuf;
    GdkBitmap *bitmap;
    GdkPixmap *pixmap;
    int height;
    int width;
    DATA data;

    gtk_init(&argc,&argv);

    win=gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_position(GTK_WINDOW(win),GTK_WIN_POS_CENTER);
    gtk_window_set_decorated(GTK_WINDOW(win),FALSE);  //�����ޱ߿�
    gtk_widget_set_app_paintable(win,TRUE);  //���ô��ڿɻ�
    gtk_widget_realize(win);
    gtk_widget_add_events(win,
            GDK_BUTTON_MOTION_MASK|GDK_BUTTON_PRESS_MASK);
    g_signal_connect(G_OBJECT(win),"button_press_event",
            G_CALLBACK(get_position),&data);
    g_signal_connect(G_OBJECT(win),"motion_notify_event",
            G_CALLBACK(move),&data);

    pixbuf=gdk_pixbuf_new_from_file("2.png",NULL); //����ͼƬ
    width=gdk_pixbuf_get_width(pixbuf)/2;
    height=gdk_pixbuf_get_height(pixbuf)/2;
    pixbuf=gdk_pixbuf_scale_simple(pixbuf,
            width,height,GDK_INTERP_BILINEAR); //����ͼƬ̫������һ��
    gtk_widget_set_size_request(win,width,height);

    gdk_pixbuf_render_pixmap_and_mask(pixbuf,&pixmap,&bitmap,128); //alphaС��128��Ϊ͸��
    gtk_widget_shape_combine_mask(win,bitmap,0,0); //����͸���ɰ�
    gdk_window_set_back_pixmap(win->window,pixmap,FALSE);  //��ͼƬ����Ϊ����

    gtk_widget_show_all(win);
    gtk_main();

    return 0;
}
