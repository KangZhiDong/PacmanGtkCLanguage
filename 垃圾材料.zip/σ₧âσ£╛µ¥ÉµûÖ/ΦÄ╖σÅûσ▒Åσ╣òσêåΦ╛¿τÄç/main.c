#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkkeysyms.h> /* the key value defines can be found here */
#include <stdio.h>

static void
on_key_press(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
    switch(event->keyval)
    {
        case GDK_Escape:
            gtk_main_quit();
            break;
        default:
            break;
    }
}
int main(int argc, char *argv[])
{
    gtk_init(&argc, &argv);
    /* Get the Screen Resolution */
    GdkScreen* screen;
    gint width, height;
    screen = gdk_screen_get_default();
    width = gdk_screen_get_width(screen);
    height = gdk_screen_get_height(screen);
    printf("screen width: %d, height: %d\n", width, height);

    /* Create window and set full screen */
    GtkWidget *window;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
    gtk_window_set_default_size(GTK_WINDOW(window), width, height);
    gtk_window_set_decorated(GTK_WINDOW(window), FALSE); /* hide the title bar and the boder */

    gtk_widget_show (window);
    /* add key event for quit */
    g_signal_connect(G_OBJECT(window),
            "key-press-event",
            G_CALLBACK(on_key_press), NULL);

    gtk_main();

    return 0;
}
