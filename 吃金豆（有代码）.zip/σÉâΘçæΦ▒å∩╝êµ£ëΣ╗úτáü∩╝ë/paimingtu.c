#include"paiming.c"
static GtkWidget*paiming_window;

//讲链表中的数据放进图形化的clist中，可以按链表输出数据
void shuchuxinxi(struct xinxi*head)
{
  struct xinxi*p;
  int n=0;
  if(head!=NULL)
  {
    printf("\nlianbiaozhongxueshengshuju:\n");
    for(p=head;p!=NULL;p=p->next)
    {

     char *a;
     sprintf(a,"%d",p->paiming);
     new_row[0]=a;
     new_row[1]=p->id;
     new_row[2]=p->score;
     new_row[3]=p->time;
     n++;

     row_count++;
    gtk_clist_append(GTK_CLIST(clist),new_row);
    }
    printf("zongshu:%d\n\n",n);
  }
  else
    printf("konglianbiao!\n\n");
}


//删除排名窗口
void on_paiming_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(paiming_window);

}
//给按钮加图片
GtkWidget* create_button (gchar* stockid)
 {   //创建图像按钮
 GtkWidget *button;
 GtkWidget *image;
 image=gtk_image_new_from_stock(stockid,GTK_ICON_SIZE_MENU);
 button=gtk_button_new();
 gtk_container_add(GTK_CONTAINER(button),image);
 return button;
 }
//四个快捷按钮的调用函数
void goto_first(GtkButton *button,gpointer data)
 {   //转首行、
 current_row=0;
 gtk_clist_select_row(GTK_CLIST(clist),current_row,0);
 }
 void goto_last(GtkButton *button,gpointer data)
 {   //转尾行、
 current_row=row_count-1;
 gtk_clist_select_row(GTK_CLIST(clist),current_row,0);
 }
 void go_back (GtkButton *button,gpointer data)
 {   //前一行
 current_row--;
 if(current_row==-1)
 return;
 gtk_clist_select_row(GTK_CLIST(clist),current_row,0);
 }
 void go_forward (GtkButton *button,gpointer data)
 {  current_row++;
 if(current_row>row_count)
 return;
 gtk_clist_select_row(GTK_CLIST(clist),current_row,0);
 } //后一行


//排名窗口的创建
GtkWidget* create_paiming_window()
 {
 GtkWidget *window;
 GtkWidget *vbox;
 GtkWidget *bbox;
 GtkWidget *button;
 GtkTooltips *button_tips;
 window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
 g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(on_paiming_delete),NULL);
 gtk_window_set_title(GTK_WINDOW(window),"查看游戏排名");
 gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("w.png"));
gtk_container_set_border_width(GTK_CONTAINER(window),10);
gtk_widget_set_size_request (window, 400, 400);
vbox=gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
clist=gtk_clist_new_with_titles(4,titles);
 gtk_clist_append(GTK_CLIST(clist),new_row);
gtk_box_pack_start(GTK_BOX(vbox),clist,TRUE,TRUE,5);
bbox=gtk_hbutton_box_new();
button_tips=gtk_tooltips_new();
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
gtk_box_set_spacing(GTK_BOX(bbox),5);
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
gtk_button_box_set_child_size(GTK_BUTTON_BOX(bbox),20,20);


shuchuxinxi(head);

button=create_button(GTK_STOCK_GOTO_FIRST);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"转到首行","首行");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(goto_first),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_GO_BACK);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"转到前一页","前一页");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(go_back),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_GO_FORWARD);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"转到下一行","下一行");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(go_forward),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_GOTO_LAST);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"转到尾行","尾行");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(goto_last),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_QUIT);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"退出","退出");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_paiming_delete),window);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,5);
gtk_widget_show_all(window);
 gdk_window_set_cursor(gtk_widget_get_window(window),
        gdk_cursor_new_from_pixbuf(gdk_display_get_default(),
                gdk_pixbuf_new_from_file("w.png",NULL),
                0,0));
return window;
}

//调用排名窗口，同时进行数据处理
void on_paiming(GtkButton*button,gpointer data)
{
    printf("paiming");
    head=loadnew();
    head=sortbytime(head);
    paiming(head);
 paiming_window=create_paiming_window();
 gtk_widget_show(paiming_window);
}
