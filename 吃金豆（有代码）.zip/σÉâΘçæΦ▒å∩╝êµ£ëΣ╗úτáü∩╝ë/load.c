//从datat。txt读出游戏信息，并复制到链表
struct xinxi*loadnew()
{
    struct xinxi*p;
    struct xinxi*p1;
    struct xinxi*p3;
    struct xinxi*p4;
    int n=0,i=0,j=0;
    FILE*fp;
    if((fp=fopen("data.txt","r"))==NULL)
    {
        printf("bunnengdakaiwenjian!\n");

    //exit(0);
    }

    else
     {

        head =(struct xinxi *)malloc(sizeof(struct xinxi));
        if(fread(head,sizeof(struct xinxi),1,fp)!=1)
            printf("meiyoushujukeyiduqu!\n\n");
        p=head;
        n++;
        while(!feof(fp))
        {
          p1= (struct xinxi *)malloc(sizeof(struct xinxi));
          fread(p1,sizeof(struct xinxi),1,fp);
          p->next=p1;
          p=p1;
          n++;
        }
        p->next=NULL;
     }
    n--;
    for(p3=head,i=0;p3!=NULL;p3=p3->next) i++;
     for(j=0,p4=head;j<i-2;j++)
     {
         p4=p4->next;
     }
     p4->next=NULL;



printf("ciciduquxueshengshu%d\n\n",n);
shuchu(head);
    fclose(fp);
    return head;
}

