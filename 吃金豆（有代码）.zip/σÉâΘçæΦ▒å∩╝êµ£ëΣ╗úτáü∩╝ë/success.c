static GtkWidget*success_window;
#include"jilu.c"
//退出游戏成功提示窗口
void on_quitsuccess_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(success_window);

}

//创建游戏成功窗口
GtkWidget*create_success_window()
{
GtkWidget* bbox;
GtkWidget* vbox;
GtkWidget* hbox;

GtkWidget* label;
GtkWidget* windows;
GtkWidget* sep;
GtkWidget* button;
GtkWidget* image;
windows = gtk_window_new(GTK_WINDOW_TOPLEVEL);
gtk_window_set_icon(GTK_WINDOW(windows), create_pixbuf("dou.png"));
gtk_window_set_title(GTK_WINDOW(windows),"恭喜攻破次关！");
g_signal_connect(G_OBJECT(windows),"delete_event",G_CALLBACK(on_quitsuccess_delete),NULL);
vbox=gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(windows),vbox);
hbox=gtk_hbox_new(FALSE,0);
gtk_box_pack_start(GTK_BOX(vbox),hbox,FALSE,FALSE,5);
image=gtk_image_new_from_stock(GTK_STOCK_DIALOG_ERROR,GTK_ICON_SIZE_DIALOG);
gtk_box_pack_start(GTK_BOX(hbox),image,FALSE,FALSE,5);
label=gtk_label_new("是否继续挑战下一关？");
gtk_box_pack_start(GTK_BOX(hbox),label,FALSE,FALSE,5);

sep = gtk_hseparator_new();
gtk_box_pack_start(GTK_BOX(vbox),sep,FALSE,FALSE,5);
bbox = gtk_hbutton_box_new();
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_EDGE);
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
button = gtk_button_new_from_stock(GTK_STOCK_OK);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,25);
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(quit),game_window);
//g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_quitsuccess_delete),NULL);
g_signal_connect(G_OBJECT(button),"released",G_CALLBACK(on_game),NULL);


button = gtk_button_new_from_stock(GTK_STOCK_CANCEL);
g_signal_connect(GTK_OBJECT(button),"released",G_CALLBACK(on_quitsuccess_delete),NULL);
g_signal_connect(GTK_OBJECT(button),"clicked",G_CALLBACK(on_jilu),NULL);

gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,35);
gtk_widget_show_all(windows);
 gdk_window_set_cursor(gtk_widget_get_window(windows),
        gdk_cursor_new_from_pixbuf(gdk_display_get_default(),
                gdk_pixbuf_new_from_file("dou.png",NULL),
                0,0));
return windows;
}

//开始调用游戏成功窗口函数
void on_success()
{
    printf("success");
 success_window=create_success_window();
 gtk_widget_show(success_window);
}
